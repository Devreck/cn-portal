#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKUP_DIR="$ROOT_DIR/backups"
STAMP="$(date +"%Y%m%d-%H%M%S")"
OUT="$BACKUP_DIR/supabase-db-$STAMP.sql"

mkdir -p "$BACKUP_DIR"

if ! command -v supabase >/dev/null 2>&1; then
  echo "Supabase CLI nao encontrado. Instale com: brew install supabase/tap/supabase" >&2
  exit 1
fi

if [[ -n "${SUPABASE_DB_URL:-}" ]]; then
  supabase db dump --db-url "$SUPABASE_DB_URL" --file "$OUT"
else
  supabase db dump --file "$OUT"
fi

gzip "$OUT"
echo "$OUT.gz"

--
-- PostgreSQL database dump
--

\restrict HDDBCc7pLPnfDOEZtQxweTwgUyeFHLhcin0OSPratR2XZOO01ntjwRG62ophs7q

-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: -
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


--
-- Name: cn_limpar_elementos_visuais_invalidos(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cn_limpar_elementos_visuais_invalidos(valor jsonb) RETURNS jsonb
    LANGUAGE sql IMMUTABLE
    AS $$
  select coalesce(
    jsonb_agg(elem),
    '[]'::jsonb
  )
  from jsonb_array_elements(coalesce(valor, '[]'::jsonb)) elem
  where
    elem ? 'tipo'
    and (
      elem->>'tipo' <> 'equacao_quimica'
      or length(trim(coalesce(elem->>'equacao', ''))) > 0
    )
    and (
      elem->>'tipo' <> 'tabela'
      or jsonb_typeof(elem->'linhas') = 'array'
    )
    and (
      elem->>'tipo' <> 'grafico_xy'
      or jsonb_typeof(elem->'series') = 'array'
    )
    and (
      elem->>'tipo' <> 'circuito_serie'
      or jsonb_typeof(elem->'componentes') = 'array'
    )
    and (
      elem->>'tipo' <> 'heredograma'
      or jsonb_typeof(elem->'geracoes') = 'array'
    );
$$;


--
-- Name: criar_usuario(text, text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.criar_usuario(p_email text, p_senha text, p_matricula text, p_nome text, p_turma text, p_role text DEFAULT 'aluno'::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
declare
  v_user_id uuid;
begin
  -- Evita duplicatas
  select id into v_user_id from auth.users where email = p_email;
  if v_user_id is not null then
    raise notice 'Usuário já existe: %', p_email;
    return v_user_id;
  end if;

  v_user_id := uuid_generate_v4();

  insert into auth.users (
    id,
    instance_id,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    role,
    aud,
    created_at,
    updated_at,
    confirmation_token,
    recovery_token
  ) values (
    v_user_id,
    '00000000-0000-0000-0000-000000000000',
    p_email,
    crypt(p_senha, gen_salt('bf')),
    now(),
    jsonb_build_object('provider', 'email', 'providers', array['email']),
    jsonb_build_object(
      'matricula', p_matricula,
      'nome',      p_nome,
      'turma',     p_turma,
      'role',      p_role
    ),
    'authenticated',
    'authenticated',
    now(),
    now(),
    '',
    ''
  );

  return v_user_id;
end;
$$;


--
-- Name: criar_usuario_professor(text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.criar_usuario_professor(p_email text, p_matricula text, p_nome text, p_turma text) RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_user_id uuid;
  v_caller_role text;
begin
  -- Verificar se quem chama é professor
  select role into v_caller_role
  from public.perfis
  where id = auth.uid();

  if v_caller_role != 'professor' then
    return json_build_object('ok', false, 'erro', 'Apenas professores podem criar usuários');
  end if;

  -- Verificar se matrícula já existe
  if exists (select 1 from public.perfis where matricula = p_matricula) then
    return json_build_object('ok', false, 'erro', 'Matrícula já cadastrada');
  end if;

  -- Criar usuário no auth.users
  v_user_id := uuid_generate_v4();

  insert into auth.users (
    id, instance_id, email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    role, aud,
    created_at, updated_at,
    confirmation_token, recovery_token,
    email_change, email_change_token_new,
    email_change_token_current, reauthentication_token
  ) values (
    v_user_id,
    '00000000-0000-0000-0000-000000000000',
    p_email,
    crypt('Marista@2026', gen_salt('bf', 10)),
    now(),
    jsonb_build_object('provider', 'email', 'providers', array['email']),
    jsonb_build_object('matricula', p_matricula, 'nome', p_nome, 'turma', p_turma, 'role', 'aluno'),
    'authenticated', 'authenticated',
    now(), now(),
    '', '', '', '', '', ''
  );

  return json_build_object('ok', true, 'user_id', v_user_id);

exception when others then
  return json_build_object('ok', false, 'erro', sqlerrm);
end;
$$;


--
-- Name: fechar_sessao(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fechar_sessao(p_sessao_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  update public.sessoes
  set
    fim              = now(),
    duracao_segundos = extract(epoch from (now() - inicio))::integer
  where id = p_sessao_id;
end;
$$;


--
-- Name: get_public_login_stats(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_public_login_stats() RETURNS TABLE(total_itens bigint, itens_ia_aprovados bigint)
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select
    120::bigint + count(*)::bigint as total_itens,
    count(*)::bigint as itens_ia_aprovados
  from public.questoes_banco
  where status in ('aprovada', 'editada');
$$;


--
-- Name: get_ranking(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_ranking() RETURNS TABLE(posicao bigint, aluno_id uuid, nome text, turma text, pontos_total integer, pontos_bio integer, pontos_quim integer, pontos_fis integer, pontos_simulado integer, streak_maximo integer, badges_count bigint)
    LANGUAGE sql SECURITY DEFINER
    AS $$
  select
    row_number() over (order by p.pontos_total desc, p.updated_at asc) as posicao,
    pf.id,
    pf.nome,
    pf.turma,
    p.pontos_total,
    p.pontos_bio,
    p.pontos_quim,
    p.pontos_fis,
    p.pontos_simulado,
    p.streak_maximo,
    count(b.id) as badges_count
  from public.pontuacao p
  join public.perfis pf on pf.id = p.aluno_id
  left join public.badges_conquistados b on b.aluno_id = pf.id
  where pf.role = 'aluno' and pf.ativo = true
  group by pf.id, pf.nome, pf.turma, p.pontos_total,
           p.pontos_bio, p.pontos_quim, p.pontos_fis,
           p.pontos_simulado, p.streak_maximo, p.updated_at
  order by posicao;
$$;


--
-- Name: get_stats_questoes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_stats_questoes() RETURNS TABLE(questao_id text, disciplina text, tipo text, total bigint, acertos bigint, taxa_acerto numeric)
    LANGUAGE sql SECURITY DEFINER
    AS $$
  select
    questao_id,
    disciplina,
    tipo,
    count(*) as total,
    count(*) filter (where correta = true) as acertos,
    round(
      count(*) filter (where correta = true)::numeric / count(*) * 100,
    1) as taxa_acerto
  from public.respostas
  group by questao_id, disciplina, tipo
  order by taxa_acerto asc;
$$;


--
-- Name: get_stats_turma(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_stats_turma() RETURNS TABLE(total_alunos bigint, alunos_ativos bigint, media_pontuacao numeric, revisoes_bio_concluidas bigint, revisoes_quim_concluidas bigint, revisoes_fis_concluidas bigint, simulados_concluidos bigint, questoes_pendentes bigint)
    LANGUAGE sql SECURITY DEFINER
    AS $$
  select
    (select count(*) from public.perfis where role = 'aluno' and ativo = true),
    (select count(distinct aluno_id) from public.sessoes
     where inicio > now() - interval '7 days'),
    (select round(avg(pontos_total), 0) from public.pontuacao),
    (select count(*) from public.progresso_revisao where disciplina = 'bio' and concluida = true),
    (select count(*) from public.progresso_revisao where disciplina = 'quim' and concluida = true),
    (select count(*) from public.progresso_revisao where disciplina = 'fis' and concluida = true),
    (select count(*) from public.simulado_tentativas where concluido = true),
    (select count(*) from public.questoes_banco where status = 'pendente');
$$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_matricula text;
  v_nome      text;
  v_turma     text;
  v_role      text;
begin
  -- Extrair metadados com segurança
  v_matricula := coalesce(new.raw_user_meta_data->>'matricula', new.email);
  v_nome      := coalesce(new.raw_user_meta_data->>'nome', new.email);
  v_turma     := new.raw_user_meta_data->>'turma';
  v_role      := coalesce(new.raw_user_meta_data->>'role', 'aluno');

  -- Inserir perfil apenas se não existir
  insert into public.perfis (id, matricula, nome, turma, email, role, senha_trocada, ativo)
  values (new.id, v_matricula, v_nome, v_turma, new.email, v_role, false, true)
  on conflict (id) do nothing;

  -- Inserir pontuação apenas se não existir
  insert into public.pontuacao (aluno_id)
  values (new.id)
  on conflict (aluno_id) do nothing;

  -- Inserir progresso das 3 disciplinas apenas se não existir
  insert into public.progresso_revisao (aluno_id, disciplina)
  values
    (new.id, 'bio'),
    (new.id, 'quim'),
    (new.id, 'fis')
  on conflict (aluno_id, disciplina) do nothing;

  return new;

exception when others then
  -- Log do erro mas não bloqueia o login
  raise warning 'handle_new_user error for %: %', new.email, sqlerrm;
  return new;
end;
$$;


--
-- Name: handle_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  new.updated_at = now();
  return new;
end;
$$;


--
-- Name: marcar_senha_trocada(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.marcar_senha_trocada() RETURNS json
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_uid uuid;
begin
  v_uid := auth.uid();
  
  if v_uid is null then
    return json_build_object('ok', false, 'erro', 'Não autenticado');
  end if;

  update public.perfis
  set senha_trocada = true, updated_at = now()
  where id = v_uid;

  if not found then
    return json_build_object('ok', false, 'erro', 'Perfil não encontrado');
  end if;

  return json_build_object('ok', true);
end;
$$;


--
-- Name: marcar_senha_trocada(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.marcar_senha_trocada(p_user_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  -- Só permite atualizar o próprio registro
  if p_user_id != auth.uid() then
    raise exception 'Acesso negado';
  end if;
  
  update public.perfis
  set senha_trocada = true, updated_at = now()
  where id = p_user_id;
end;
$$;


--
-- Name: recalcular_pontuacao(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.recalcular_pontuacao(p_aluno_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  update public.pontuacao
  set
    pontos_total = pontos_bio + pontos_quim + pontos_fis + pontos_simulado + pontos_bonus,
    updated_at   = now()
  where aluno_id = p_aluno_id;
end;
$$;


--
-- Name: simulado_desbloqueado(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.simulado_desbloqueado(p_aluno_id uuid) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
declare
  v_concluidas integer;
begin
  select count(*) into v_concluidas
  from public.progresso_revisao
  where aluno_id = p_aluno_id
    and concluida = true;

  return v_concluidas >= 3;
end;
$$;


--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_
        -- Filter by action early - only get subscriptions interested in this action
        -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
        and (subs.action_filter = '*' or subs.action_filter = action::text);

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL AND ppt.tablename NOT LIKE '% %'),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  -- Count raw slot entries before apply_rls/subscription filter
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  -- Apply RLS and filter as before
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  -- Real rows with slot count attached
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  -- Sentinel row: always returned when no real rows exist so Elixir can
  -- always read slot_changes_count. Identified by wal IS NULL.
  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    -- Generate a new UUID for the id
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: badges_conquistados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.badges_conquistados (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    aluno_id uuid NOT NULL,
    badge_id text NOT NULL,
    conquistado_em timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notificacoes_professor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notificacoes_professor (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    professor_id uuid NOT NULL,
    tipo text NOT NULL,
    referencia_id uuid,
    mensagem text NOT NULL,
    lida boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notificacoes_professor_tipo_check CHECK ((tipo = ANY (ARRAY['nova_questao'::text, 'questao_editada'::text, 'novo_aluno'::text])))
);


--
-- Name: perfis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.perfis (
    id uuid NOT NULL,
    matricula text NOT NULL,
    nome text NOT NULL,
    turma text,
    email text NOT NULL,
    role text DEFAULT 'aluno'::text NOT NULL,
    senha_trocada boolean DEFAULT false NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT perfis_role_check CHECK ((role = ANY (ARRAY['aluno'::text, 'professor'::text])))
);


--
-- Name: pontuacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pontuacao (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    aluno_id uuid NOT NULL,
    pontos_bio integer DEFAULT 0 NOT NULL,
    pontos_quim integer DEFAULT 0 NOT NULL,
    pontos_fis integer DEFAULT 0 NOT NULL,
    pontos_simulado integer DEFAULT 0 NOT NULL,
    pontos_bonus integer DEFAULT 0 NOT NULL,
    pontos_total integer DEFAULT 0 NOT NULL,
    streak_atual integer DEFAULT 0 NOT NULL,
    streak_maximo integer DEFAULT 0 NOT NULL,
    questoes_respondidas integer DEFAULT 0 NOT NULL,
    questoes_corretas integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: progresso_revisao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.progresso_revisao (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    aluno_id uuid NOT NULL,
    disciplina text NOT NULL,
    total_questoes integer DEFAULT 0 NOT NULL,
    acertos integer DEFAULT 0 NOT NULL,
    concluida boolean DEFAULT false NOT NULL,
    percentual numeric(5,2) DEFAULT 0 NOT NULL,
    ultima_atividade timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT progresso_revisao_disciplina_check CHECK ((disciplina = ANY (ARRAY['bio'::text, 'quim'::text, 'fis'::text])))
);


--
-- Name: questoes_banco; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.questoes_banco (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    origem text DEFAULT 'ia_gerada'::text NOT NULL,
    gerada_para uuid,
    disciplina text NOT NULL,
    tema text NOT NULL,
    subtema text,
    tipo text NOT NULL,
    nivel text NOT NULL,
    interdisciplinar_com text[],
    enunciado text NOT NULL,
    texto_base jsonb,
    alternativas jsonb,
    gabarito text NOT NULL,
    explicacao text NOT NULL,
    steps jsonb,
    elementos_visuais jsonb,
    status text DEFAULT 'pendente'::text NOT NULL,
    revisada_por uuid,
    revisada_em timestamp with time zone,
    nota_revisor text,
    vezes_usada integer DEFAULT 0 NOT NULL,
    total_respostas integer DEFAULT 0 NOT NULL,
    total_acertos integer DEFAULT 0 NOT NULL,
    taxa_acerto numeric(5,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT questoes_banco_disciplina_check CHECK ((disciplina = ANY (ARRAY['bio'::text, 'quim'::text, 'fis'::text, 'inter'::text]))),
    CONSTRAINT questoes_banco_nivel_check CHECK ((nivel = ANY (ARRAY['basico'::text, 'intermediario'::text, 'avancado'::text]))),
    CONSTRAINT questoes_banco_origem_check CHECK ((origem = ANY (ARRAY['manual'::text, 'ia_gerada'::text]))),
    CONSTRAINT questoes_banco_status_check CHECK ((status = ANY (ARRAY['pendente'::text, 'aprovada'::text, 'editada'::text, 'rejeitada'::text]))),
    CONSTRAINT questoes_banco_tipo_check CHECK ((tipo = ANY (ARRAY['A'::text, 'C'::text])))
);


--
-- Name: respostas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.respostas (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    aluno_id uuid NOT NULL,
    questao_id text NOT NULL,
    disciplina text NOT NULL,
    tipo text NOT NULL,
    correta boolean NOT NULL,
    tempo_segundos integer,
    streak_momento integer DEFAULT 0 NOT NULL,
    pontos_ganhos integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT respostas_disciplina_check CHECK ((disciplina = ANY (ARRAY['bio'::text, 'quim'::text, 'fis'::text]))),
    CONSTRAINT respostas_tipo_check CHECK ((tipo = ANY (ARRAY['A'::text, 'C'::text])))
);


--
-- Name: sessoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessoes (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    aluno_id uuid NOT NULL,
    pagina text NOT NULL,
    inicio timestamp with time zone DEFAULT now() NOT NULL,
    fim timestamp with time zone,
    duracao_segundos integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: simulado_respostas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.simulado_respostas (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    aluno_id uuid NOT NULL,
    questao_id text NOT NULL,
    disciplina text NOT NULL,
    tipo text NOT NULL,
    correta boolean NOT NULL,
    tempo_segundos integer,
    pontos_ganhos integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT simulado_respostas_disciplina_check CHECK ((disciplina = ANY (ARRAY['bio'::text, 'quim'::text, 'fis'::text, 'inter'::text]))),
    CONSTRAINT simulado_respostas_tipo_check CHECK ((tipo = ANY (ARRAY['A'::text, 'C'::text])))
);


--
-- Name: simulado_solicitacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.simulado_solicitacoes (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    professor_id uuid NOT NULL,
    titulo text DEFAULT 'Novo simulado'::text NOT NULL,
    foco text NOT NULL,
    quantidade_itens integer DEFAULT 60 NOT NULL,
    status text DEFAULT 'solicitado'::text NOT NULL,
    observacoes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT simulado_solicitacoes_quantidade_itens_check CHECK (((quantidade_itens >= 20) AND (quantidade_itens <= 120))),
    CONSTRAINT simulado_solicitacoes_status_check CHECK ((status = ANY (ARRAY['solicitado'::text, 'em_producao'::text, 'concluido'::text, 'cancelado'::text])))
);


--
-- Name: simulado_tentativas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.simulado_tentativas (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    aluno_id uuid NOT NULL,
    iniciado_em timestamp with time zone DEFAULT now() NOT NULL,
    finalizado_em timestamp with time zone,
    tempo_total_segundos integer,
    pontos_obtidos integer DEFAULT 0 NOT NULL,
    concluido boolean DEFAULT false NOT NULL,
    tentativa_num integer DEFAULT 1 NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
677eecb6-5c3c-4908-9972-3e72cb03c203	2026-05-23 20:47:14.034333+00	2026-05-23 20:47:14.034333+00	password	905380b2-bd5d-42d3-abc6-c477ffb45c45
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	16	rvn3n5vdo2yz	f323e9ea-5121-4d6b-b39e-a0029d45b90b	f	2026-05-23 20:47:14.032974+00	2026-05-23 20:47:14.032974+00	\N	677eecb6-5c3c-4908-9972-3e72cb03c203
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
677eecb6-5c3c-4908-9972-3e72cb03c203	f323e9ea-5121-4d6b-b39e-a0029d45b90b	2026-05-23 20:47:14.031969+00	2026-05-23 20:47:14.031969+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	179.173.95.38	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	00000000-0000-0000-0000-000000000099	authenticated	authenticated	teste@maristabrasil.g12.br	$2a$10$W7k9Kq0hUtiwv207F4Snqed6YQB.gIDK3Em9X/IIeJTrDMCxCTSSa	2026-05-23 19:00:59.36899+00	\N		\N		\N			\N	2026-05-23 19:18:37.112337+00	{"provider": "email", "providers": ["email"]}	{"nome": "ALUNO TESTE", "role": "aluno", "turma": "23A", "matricula": "TESTE01"}	\N	2026-05-23 19:00:59.36899+00	2026-05-23 20:23:38.872496+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f323e9ea-5121-4d6b-b39e-a0029d45b90b	authenticated	authenticated	deyko.teixeira@maristabrasil.org	$2a$10$8CUDTFPiJ4pRiVC8APGfpeqi.8HkP5JmtDoMItXbB5g6uRjJwWJIC	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	2026-05-23 20:47:14.031876+00	{"provider": "email", "providers": ["email"]}	{"nome": "DEYKO TEIXEIRA", "role": "professor", "turma": null, "matricula": "PROF001"}	\N	2026-05-22 21:25:43.933275+00	2026-05-23 20:47:14.033933+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1d6225f2-361d-4a21-8ee6-9ce6abd08b6e	authenticated	authenticated	rosely.braz@maristabrasil.org	$2a$10$DMvQX0ay5wxMhnN/gelFNuWSIhG5ZmcLyqaWWFoi5bXWUGeDcSDTu	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ROSELY BRAZ", "role": "professor", "turma": null, "matricula": "PROF002"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	505e2654-511a-4fad-852c-10c1a20577b9	authenticated	authenticated	2043240330@maristabrasil.g12.br	$2a$10$zDkiy/bxaVkrG3UdFeB3IOnLZfoItBkMd9.DNq3N07.i1ZDUQAkDO	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MAITÊ CAVALCANTE LIMA GARBINI DE FIGUEIREDO", "role": "aluno", "turma": "23C", "matricula": "2043240330"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f482e70c-94ec-4a48-9699-a47315a5ec3a	authenticated	authenticated	2043220072@maristabrasil.g12.br	$2a$10$etByNGfJ2Je0eOxVdpt7O.5uDLZk7Ibm6Ed4P20BH/wCt.Yml6CwW	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MANUELA MONTÓN DA COSTA", "role": "aluno", "turma": "23C", "matricula": "2043220072"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	bff8f563-6312-4c35-bd6c-bf150a598567	authenticated	authenticated	2043240217@maristabrasil.g12.br	$2a$10$rMZAAmqI1mUB37ONjtNm0.ecryQ/MLDmrKMWB6f/ghm7fTTmclKji	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIA CLARA LOPES DE OLIVEIRA SILVA", "role": "aluno", "turma": "23C", "matricula": "2043240217"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e6731988-19f7-4a6d-a583-562978836228	authenticated	authenticated	2043150319@maristabrasil.g12.br	$2a$10$KC5Dcif5AnjmYnVhdlrdfe7JI45IE3jemADqMSnCzDup2ryVS.eDu	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIA CLARA SOUZA LAROCCA RIGAILO", "role": "aluno", "turma": "23C", "matricula": "2043150319"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1b52a101-47f5-4eca-b6f1-d9c856a9377d	authenticated	authenticated	2043160385@maristabrasil.g12.br	$2a$10$OKn53QuB9r.H/Nfq3NfmaOZxnS/gAJwdtWt/4LJfw6o1flp62D5Qi	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARINA ROCHA CABRAL", "role": "aluno", "turma": "23C", "matricula": "2043160385"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	80d358a7-79b3-47bd-9a81-c58e9c5cc5d7	authenticated	authenticated	joao.bruno@maristabrasil.org	$2a$10$OGODZTTlSZcSE8q7Zbyze.y4wn6J.VuuIF3oSrIXbP8.1b1fHGH/K	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JOÃO BRUNO", "role": "professor", "turma": null, "matricula": "PROF003"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5f90fcd7-8d06-4653-bfb3-2c25cfc092d9	authenticated	authenticated	2043260353@maristabrasil.g12.br	$2a$10$g7VZBjtbDjdxop5r3vlHPeI2RZNIyA96nD2EqcLXb9ICfmRWJ917G	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ÁLVARO AMORIM CUNHA MARTINS", "role": "aluno", "turma": "23A", "matricula": "2043260353"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	92e05c61-74a1-401d-8d52-ea0f420e87a8	authenticated	authenticated	2043130157@maristabrasil.g12.br	$2a$10$/vwKRLRRp.d8Yh0/f6F3q.69jQ8QHFbzlJssSMCJ1U65.l5Gc18Me	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "CAROLINA BORGES FURTADO NEVES", "role": "aluno", "turma": "23A", "matricula": "2043130157"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a46db1b2-ccc3-488e-91af-0a98d7730adc	authenticated	authenticated	2043160370@maristabrasil.g12.br	$2a$10$IG3FNNPlKBMCoP4XIf47UuNCx0Zz1UQi1HVK8c.XBR5UyiJf2jeAa	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "FERNANDA RIBEIRO LIMA", "role": "aluno", "turma": "23A", "matricula": "2043160370"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	92462d59-6c01-4e39-8695-b8a468e87617	authenticated	authenticated	2043220170@maristabrasil.g12.br	$2a$10$ShsM1UmsMZAkiTtliyAMIes3rKgiVSCmz90wRZ0Ipmw6rIco7PONK	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "FRANCISCO PEREIRA DE SOUSA SILVEIRA", "role": "aluno", "turma": "23A", "matricula": "2043220170"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	83125671-5a73-4d97-bde1-0bf31ecee37d	authenticated	authenticated	2043160234@maristabrasil.g12.br	$2a$10$pa8GDoraa0kAEtD6hvP3tOMpT9wUv2IE5jNwVJh4OSYozEHS4Hy5i	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "GIOVANNA FERNANDES ABEN ATHAR", "role": "aluno", "turma": "23A", "matricula": "2043160234"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	fd86a8c1-1bd2-4b9d-b79e-ab7f65bdeb03	authenticated	authenticated	2043150245@maristabrasil.g12.br	$2a$10$iK3gW96fxQPF.uYS3UUppOlagZa6FPgJfB6kW3v/I05HMK2qARNaG	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "GUSTAVO HENRIQUE MOTTA MOREIRA", "role": "aluno", "turma": "23A", "matricula": "2043150245"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7359f307-9094-4f06-b763-621c309dc921	authenticated	authenticated	2043250326@maristabrasil.g12.br	$2a$10$fYgniusbRwVJ5kUkts8KF.l7/p6To2yL9tl4nU7HufdB/0vAlJlSS	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ISADORA GUIMARÃES MADRUGA SINOTT LOPES", "role": "aluno", "turma": "23A", "matricula": "2043250326"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	bd9c30b5-ea7f-48a4-a530-a33d38122d50	authenticated	authenticated	2043200081@maristabrasil.g12.br	$2a$10$QV7kRRSmd2pw3y52UKRYi.QrgfzgAvvJqbRC5gU5JU0W5uOGiJSsy	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JOÃO PEDRO NOBRE REIS", "role": "aluno", "turma": "23A", "matricula": "2043200081"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7cf5e3e8-7e5d-42f3-b40d-ab974aa5b452	authenticated	authenticated	2043250321@maristabrasil.g12.br	$2a$10$2/o8mtwAn7GEg7LegTwojOmak3J223ksq.L8rsyGstxSg7w4jDTKS	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JOÃO VITOR LIMA ANDRADE", "role": "aluno", "turma": "23A", "matricula": "2043250321"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	09be4886-2692-4904-9db3-8278fbe25010	authenticated	authenticated	2043240189@maristabrasil.g12.br	$2a$10$fns/01hCA/edZozv3qpn6OpIM03a5QME9yz7Hvjxx6hJyLGwx8QLm	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JÚLIO RAMOS DE SOUZA E SILVA", "role": "aluno", "turma": "23A", "matricula": "2043240189"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5dd13d2e-ffa2-4fe6-bf8f-ba72b010f9d5	authenticated	authenticated	2043220181@maristabrasil.g12.br	$2a$10$4K2tQNrOiRZLwi0kT8/WvuntRYSvN5mbT0pcg5fvnNMKFi2b2e2Gm	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LETÍCIA DE AZEVEDO E OLIVEIRA", "role": "aluno", "turma": "23A", "matricula": "2043220181"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4d41e102-8047-4aea-ba49-2262cbc05d30	authenticated	authenticated	2043120116@maristabrasil.g12.br	$2a$10$NOuCCjAQ6UtbWzpaSsIBVO9h0uIzBPHbo5cDyeuH9kdyenMnyVfoG	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LETÍCIA VAZ DA COSTA RIBEIRO", "role": "aluno", "turma": "23A", "matricula": "2043120116"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5c716e9c-b1e4-4da8-8b6c-66e63649ae44	authenticated	authenticated	2043240019@maristabrasil.g12.br	$2a$10$7uYDmb/s1ip.Mo6SGegTVuWWMb3YwH6WqU020bO02dScsNIhsBP/K	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LOUISE REZENDE DE OLIVEIRA", "role": "aluno", "turma": "23A", "matricula": "2043240019"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	9297f341-0235-433e-a66c-5ca6bff0411a	authenticated	authenticated	2043140164@maristabrasil.g12.br	$2a$10$kFaDvegPqI66hhSA/lm2VO0cw7lepICIRoAi3YPOXJIOQzQkPmvHC	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LUCAS AKIRA YOSHIMINE SILVA", "role": "aluno", "turma": "23A", "matricula": "2043140164"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	92b7acff-0598-4d6b-9d9f-5a8ee2cff04e	authenticated	authenticated	2043240186@maristabrasil.g12.br	$2a$10$W5uerqFpKMAQO2pJ8YurIO2/ONhqKiuRjgvSrpEerqS3gPBXjC3gO	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LUCAS CARVALHO SILVEIRA", "role": "aluno", "turma": "23A", "matricula": "2043240186"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4bdfea0d-31ba-4f06-80f7-3854d27d6a43	authenticated	authenticated	2043250119@maristabrasil.g12.br	$2a$10$.EPGmD7ggd.LZQctGvWUjeGb8wWUBbT17MhmM0XTw9ajJHInJS6jC	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIA FERNANDA BEDIN WELTER", "role": "aluno", "turma": "23A", "matricula": "2043250119"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2773bc2f-8365-43d6-a173-54dbe1a3713d	authenticated	authenticated	2043170184@maristabrasil.g12.br	$2a$10$zrJcf1Vt0p0W08ojQkLmnO66ywdB2eZuKkOMBdzuz5JQoEgXVtrYa	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIA LUISA CARVALHO MESQUITA", "role": "aluno", "turma": "23A", "matricula": "2043170184"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a9751085-e9a8-4cb0-97ef-1ed8cb247ce4	authenticated	authenticated	2043250217@maristabrasil.g12.br	$2a$10$ngY7Fggq.Ywcw1s.WLNF9.xy6279uvkAX2t3e5RjuyK/01ad0OO1m	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIA LUIZA PIMENTA DE SOUSA", "role": "aluno", "turma": "23A", "matricula": "2043250217"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f5cf157c-e6cd-4e3c-9864-46878fad13ba	authenticated	authenticated	2043230167@maristabrasil.g12.br	$2a$10$0MyaI55Z39fFze7hFZ8T5eEMx9stULFFv0doOPWxUhDoxeh2GzWK2	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIA THAYLA OLIVEIRA LACERDA", "role": "aluno", "turma": "23A", "matricula": "2043230167"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	30cbe8c9-4c3d-45a8-9a7b-893ba0497e89	authenticated	authenticated	2043240003@maristabrasil.g12.br	$2a$10$lAUvPGIvBl0cr7EmyW9S2eEU9Ilz676u9p3CqDgAXsx5o1AJxK.ba	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIANA BEATRIZ SOARES COELHO DA COSTA", "role": "aluno", "turma": "23A", "matricula": "2043240003"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2099c68d-f84b-474a-b6c0-fedb9b1f2dbe	authenticated	authenticated	2043120068@maristabrasil.g12.br	$2a$10$LQR274QWNqjnpPQZ4ja7M.OTvHMH2VYYYoGWR5DleEzIyNxKfga9S	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "NÍCOLAS TARSITANO NOBRE", "role": "aluno", "turma": "23A", "matricula": "2043120068"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5207f053-a1a3-4224-9a4a-15aa27ab27ce	authenticated	authenticated	2043230175@maristabrasil.g12.br	$2a$10$rIRWraMazUKNieb4hPFoRuU1DPhJ3/YmPWF85xe0/f0GI9cAzjZbm	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "NINA HARTMANN E SÁ", "role": "aluno", "turma": "23A", "matricula": "2043230175"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	674617f0-5753-4bfd-af59-9e928db0e357	authenticated	authenticated	2043240393@maristabrasil.g12.br	$2a$10$B/azZJv5I./4ruIvb7Sfy.dp/lnyuBVYw..OHHu49aZawZfz2G9I.	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "OTÁVIO ALVES GALVÃO NETO", "role": "aluno", "turma": "23A", "matricula": "2043240393"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4ec48451-e8a7-41d8-9a25-b14fb6712661	authenticated	authenticated	2043150381@maristabrasil.g12.br	$2a$10$GzHk1D5OihfRBt7vSXBEfOHKQ9ZdVrwW3QHkp7DNI9PjXtN1dLzHW	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "PEDRO ROMANO PONTES DE FARIA CAMPOS", "role": "aluno", "turma": "23A", "matricula": "2043150381"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	9d1f13c8-6094-4a74-9f29-a7cc65d4daf1	authenticated	authenticated	2043250219@maristabrasil.g12.br	$2a$10$G88l6eZWaiWfn91Lw.R6MOL167l.5HZlYX2uGnIrFHxnrvv7JHDiq	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "REBECA MOURA MARTINS", "role": "aluno", "turma": "23A", "matricula": "2043250219"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f2dc6958-ad52-4c4f-aa62-11e985a625b8	authenticated	authenticated	2043240197@maristabrasil.g12.br	$2a$10$8wi/vupqZ/UnhGO94ilp7.fniphWxtWU135yZX8Ic7E5BY7F3DXVi	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "RENERSON KOHLER FEDALTO FILHO", "role": "aluno", "turma": "23A", "matricula": "2043240197"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	69b57770-bdd8-45d6-aca7-cb686c71c233	authenticated	authenticated	2043240297@maristabrasil.g12.br	$2a$10$uwZsN7EfTnc7pTdQsEAzWOPaZ9osvKiRdb1awS9R714Xvk1CpfnqG	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "SELTON FELIPE DA SILVA FURTADO", "role": "aluno", "turma": "23A", "matricula": "2043240297"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	48f0060b-5248-4868-9d8e-7844ab57d27b	authenticated	authenticated	2043160237@maristabrasil.g12.br	$2a$10$pH4YOysfjJY/MxQm55G4Vuy0WeKAmIXR1mDqmev7Zif49D.1.KlBK	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "VALENTINA MESQUITA FIGUEIREDO", "role": "aluno", "turma": "23A", "matricula": "2043160237"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	042e9758-bae0-49e3-a53d-cd98b75d9a39	authenticated	authenticated	2043240364@maristabrasil.g12.br	$2a$10$gxX5L3To9dNiMldH3TPCnOBl/LHTbRqOS7x9n.sAGmSdmbLpFIiGG	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "VALENTINA VALE DO MONTE ROSA", "role": "aluno", "turma": "23A", "matricula": "2043240364"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6c8e4fff-fc9a-4a33-8d68-f4a86b381339	authenticated	authenticated	2043150218@maristabrasil.g12.br	$2a$10$Ovm6MJuldjV8cVT3UaD56ebaZWr5XOcGRD2PLhT8cBCxeKMyK0TnW	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ANA SOPHIA SOUSA GUIMARÃES", "role": "aluno", "turma": "23B", "matricula": "2043150218"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e7382a51-1499-4d35-9f4d-42731fcf6c49	authenticated	authenticated	2043240313@maristabrasil.g12.br	$2a$10$YWEh8rqLVYxZysvRrsXj0uBn2xE.vuLRddIPLe0XFVUCkd6UOLYlO	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ARTUR ROTH BRASIL FERREIRA", "role": "aluno", "turma": "23B", "matricula": "2043240313"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	439eb8e6-59d0-4f2f-b210-f4da6ad5efa2	authenticated	authenticated	2043200125@maristabrasil.g12.br	$2a$10$iLWBmCMIiZp5xUSWRE.lru5v/Sn6oGCX5HQWcmw6Mi0CxSfeV9CPi	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "BRUNO LUSTZ RODRIGUES", "role": "aluno", "turma": "23B", "matricula": "2043200125"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	739bd399-855c-4043-b4b2-e2418079c7bf	authenticated	authenticated	2043150379@maristabrasil.g12.br	$2a$10$StARWAd6QAhJRnagNOdYIuwB9bqy1iWVSSFK4e23/I3LbhoNwLWOG	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "CAMILA OKADA LINARES SANTOS", "role": "aluno", "turma": "23B", "matricula": "2043150379"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7ff1cfc4-7ff0-4013-b032-369ce8d25f0b	authenticated	authenticated	2043200190@maristabrasil.g12.br	$2a$10$rFU0TtUjt1abqm.JSyN6EeVeA6UNAwc4i5trzMxH..g42bdHmO9ha	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "CLARA TAVARES COMETTI", "role": "aluno", "turma": "23B", "matricula": "2043200190"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	caf69fa5-7a26-4c5d-b83d-309ab92d11b0	authenticated	authenticated	2043140047@maristabrasil.g12.br	$2a$10$OMUIKWPO020w4oecTV65deOyRm0e508P.38SuZ3IMQiOfOGSQnVHu	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "FERNANDA SANT´ANNA DE ANDRADE", "role": "aluno", "turma": "23B", "matricula": "2043140047"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f135bb07-4559-4c15-9c42-39851a743b6c	authenticated	authenticated	2043230202@maristabrasil.g12.br	$2a$10$l7nEt2YHi1VDZHh4PxvJG.jyDIBDf0DWX/ilR/4UarTnctZBhr9Ky	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "FLOR MARIANA ENCARNAÇÃO CIDADE", "role": "aluno", "turma": "23B", "matricula": "2043230202"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f14fe5d9-8dd1-4dd1-ab7b-b8326f65a534	authenticated	authenticated	2043200098@maristabrasil.g12.br	$2a$10$lXqFshlTMqYi.LsTzll66uxE40qwV/xUDw34wRgWtmRueE9pNAvVa	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "FRANCISCO ALBERT KAHN STEPHAN", "role": "aluno", "turma": "23B", "matricula": "2043200098"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	dd050ead-d327-48a6-84a8-e37e46a63a51	authenticated	authenticated	2043190218@maristabrasil.g12.br	$2a$10$hQ6/3Xt/8YD0/ql/bNQTZOrOGLCi62fMAm1jS2xUivcsgExXTlNIe	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "FRANCISCO LLERAS MELLO", "role": "aluno", "turma": "23B", "matricula": "2043190218"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	90efcdd5-0b92-42e7-96d7-bfecbd477eb0	authenticated	authenticated	2043240385@maristabrasil.g12.br	$2a$10$RpuEnM7Z6QJwJl5yijobweDvjoHGsFZOJ9qET22QTstsiYOMyJAXa	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "GABRIEL VÖLKER LACERDA", "role": "aluno", "turma": "23B", "matricula": "2043240385"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ef0cd2ed-b9ad-4e37-b2eb-df7282d13521	authenticated	authenticated	2043150242@maristabrasil.g12.br	$2a$10$XWizPQPOZzcFIh5g1tsMvejdgHNEbHwzLqTwTM4jW0nA/iIQXu3RG	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "GUILHERME DE SOUZA NOGUEIRA DE ANDRADE", "role": "aluno", "turma": "23B", "matricula": "2043150242"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5c69f88a-f85a-4b09-a0f8-385e48ad7545	authenticated	authenticated	2043230132@maristabrasil.g12.br	$2a$10$kx5zX/tVWLZuaTPydeXaFu7AmLPs4PN.fEuszWKvPNwcvoUm0vp5W	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "GUSTAVO MENDES MAGALHÃES", "role": "aluno", "turma": "23B", "matricula": "2043230132"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a7c06b24-9822-4284-9ee1-cf1ca4359826	authenticated	authenticated	2043230196@maristabrasil.g12.br	$2a$10$yenCXU.YKOui3lFdNvofaeeCKq0S4UIUBxkstuihGBp8csCS6Dlka	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "IARA TEIXEIRA SAUERBRONN", "role": "aluno", "turma": "23B", "matricula": "2043230196"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e6470169-b326-46a5-989a-878256637114	authenticated	authenticated	2043150084@maristabrasil.g12.br	$2a$10$0quYlwS2nxysT4mFmt.AwOkLb61pWw/jj/vMp59RRevBzRAbEdPqi	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "IGOR BALDUINO DE GUSMÃO", "role": "aluno", "turma": "23B", "matricula": "2043150084"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	28ee21dd-7885-4a15-9981-d04b6aafa1c3	authenticated	authenticated	2043230124@maristabrasil.g12.br	$2a$10$DQwcOgAImV..YiiSVtHk/.vSVAKxLAwr5gX336x.g2elA7pchx2Bm	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "IVANA MEI LEITE PEREIRA", "role": "aluno", "turma": "23B", "matricula": "2043230124"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e46f7fac-97c5-4aa6-abd3-1757993bde9b	authenticated	authenticated	2043140315@maristabrasil.g12.br	$2a$10$Uce8LN.AHs40MwzaVme.YunsAxX.PGKbkB8dZDHysJrVahh9/QY12	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JOÃO PEDRO MAIA TEIXEIRA", "role": "aluno", "turma": "23B", "matricula": "2043140315"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3effd2a9-babf-4354-bb8c-11eaaff840d1	authenticated	authenticated	2043150310@maristabrasil.g12.br	$2a$10$QsdCF0moqve99cfOixK7QuEhoF045jHJJ20i1gegJM4i1Y1WBK2w6	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JÚLIA LEMES SILVA", "role": "aluno", "turma": "23B", "matricula": "2043150310"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7d5384a9-b88b-4987-84cc-f821434dca1e	authenticated	authenticated	2043250293@maristabrasil.g12.br	$2a$10$3z642zokhm4OfA91EQtzueZw0xk3sjHhhvBJ8vb0J0.tvTgPh71KG	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JÚLIA SANTOS FONTINELE E SILVA", "role": "aluno", "turma": "23B", "matricula": "2043250293"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	21ac53ee-2851-4be1-83f5-d81ff829621a	authenticated	authenticated	2043240020@maristabrasil.g12.br	$2a$10$YpvbzT43C9QJqi9eogXE/.8memrb1DwuqSC7Hz/VrWS2F2uM5vmB2	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LAÍS REZENDE DE OLIVEIRA", "role": "aluno", "turma": "23B", "matricula": "2043240020"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	19cb15cb-cd51-4223-8d70-ba18545777d3	authenticated	authenticated	2043190025@maristabrasil.g12.br	$2a$10$hmc2AczqWsFkKREQoqFG1uwSG7i/0zNQ1NHEBS5mhdiilxj.exfPK	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LORENA ALVES REINA ALVES", "role": "aluno", "turma": "23B", "matricula": "2043190025"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	cc10e0a1-89cb-42b1-bf8c-c396346c2e9a	authenticated	authenticated	2043160304@maristabrasil.g12.br	$2a$10$/9JX1Da8jGAKQhiPFiflLu5JV7Tf3t7AcBv4Fb2rYA5EUFlQyQg5q	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LUÍSA MARIM DOS SANTOS", "role": "aluno", "turma": "23B", "matricula": "2043160304"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f764f07f-ac16-4458-bddf-961c3a068bba	authenticated	authenticated	2043240386@maristabrasil.g12.br	$2a$10$d0ltoE5AfTYXK0.ooobKYOe31c.Ksjj.76k6YJHU1BW03uzVHRjV.	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LUIZA NÓBREGA REZENDE CORTEZ", "role": "aluno", "turma": "23B", "matricula": "2043240386"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3e334047-c1e3-49ee-8a80-351bd12b15eb	authenticated	authenticated	2043250320@maristabrasil.g12.br	$2a$10$f/v7DtSfhW30qDpvZMcG8.VwfY90/T7IYDRhUSPvHLPOK0nUC4VSu	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIA EDUARDA BARBOSA LIMA", "role": "aluno", "turma": "23B", "matricula": "2043250320"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f166e388-c817-4dfb-90b1-91ce3f409af5	authenticated	authenticated	2043220089@maristabrasil.g12.br	$2a$10$w4ZD6COvDSHkmoy7.KV2X.7TmMU55JkiIan9vDT/KpH0R5gASNpNe	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIA EDUARDA GUIMARÃES BEZERRA DE MENEZES", "role": "aluno", "turma": "23B", "matricula": "2043220089"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	84794059-1303-4c66-84e5-638b287ddc74	authenticated	authenticated	2043170273@maristabrasil.g12.br	$2a$10$/REPmrzSc6GVXTd/aJRNY.ea3VhFqE8U1daj6jfDbHn84lS/yWShK	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MARIANA DE ARAGÃO SANJAD", "role": "aluno", "turma": "23B", "matricula": "2043170273"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1d9b1a3b-dabe-43cb-ba5a-7878d7d9c1ba	authenticated	authenticated	2043240017@maristabrasil.g12.br	$2a$10$QK0ZeWuEIFw0pGFAvy4vw.GG8hLoD3aNpKvlhUBvr2esmDj381JHO	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MATEUS CRISTIANO QUEIROZ DA SILVA GOMES", "role": "aluno", "turma": "23B", "matricula": "2043240017"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a62219d6-10a8-4676-a048-6aa258c7b50c	authenticated	authenticated	2043140375@maristabrasil.g12.br	$2a$10$Ye7xvWp2q/0xiAtZzJeJDO0MvAq5LdrAs/zsAR0AdcjVXP30S7b0K	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MATEUS DE OLIVEIRA CARVALHO", "role": "aluno", "turma": "23B", "matricula": "2043140375"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	aa937fb5-9a49-4e67-8bb5-e0f7a594c41d	authenticated	authenticated	2043190290@maristabrasil.g12.br	$2a$10$R3URiyhUboBADmji/ZY4yO6OewP.X0/6wguGljf2/UsvbFJZ90SZy	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MEL AVILA MALLAB", "role": "aluno", "turma": "23B", "matricula": "2043190290"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	8b1a0f39-934e-4a17-9b3d-15fd50f3cb94	authenticated	authenticated	2043260324@maristabrasil.g12.br	$2a$10$9NO7nJ/OL4ii3n8Xm.E7..Ox.m2vg/IeEyXcV7abeUAJwJLJlJSBa	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "MÔNICA GUIMARÃES MACEDO", "role": "aluno", "turma": "23B", "matricula": "2043260324"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4a403d53-61c3-49ea-a881-705cbe397dcf	authenticated	authenticated	2043160214@maristabrasil.g12.br	$2a$10$AMiD1rx9XFFh4d8wwZe0rOnZQTN02iYfFfhCM0zKO/mp73ee5i9z2	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "PEDRO HENRIQUE SANTOS DE ALMEIDA", "role": "aluno", "turma": "23B", "matricula": "2043160214"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6af419cf-6199-4584-9b43-aa78faad995b	authenticated	authenticated	2043250308@maristabrasil.g12.br	$2a$10$lHIDu2PKI3eTbPMr4tcZ/efngNgENGaizXzJeP8y/zbRUyo60GY8q	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "SANDRA REGINA SOUZA DOS SANTOS", "role": "aluno", "turma": "23B", "matricula": "2043250308"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7606a6f5-17c5-4b67-945a-4772fd826a01	authenticated	authenticated	2043240318@maristabrasil.g12.br	$2a$10$63BEYcqTsqUbfOFX135wkOq0jhjYUhHcva3OEoDoR0qgLZcv13LLq	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "TERESA FERNANDES MONDONI", "role": "aluno", "turma": "23B", "matricula": "2043240318"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	62a9266b-1027-4502-b1ae-8b902dfe7fec	authenticated	authenticated	2043130162@maristabrasil.g12.br	$2a$10$cB1vIEnpyCkgGjUVbp1qveipa8umMZA3oSYhNIWg46SYcX120ldpm	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "THEO DE LUCENA CASARIN DALMAS", "role": "aluno", "turma": "23B", "matricula": "2043130162"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	89e6e076-438c-4c5b-87ce-b559ae9cc66c	authenticated	authenticated	2043260346@maristabrasil.g12.br	$2a$10$q9mz7AQfpRHbfz/J/B8gQO4gLbeY7u.//muYqkYbDipGuZzDb26Z2	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ANA AROSO SANTOS", "role": "aluno", "turma": "23C", "matricula": "2043260346"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b3693735-c3f7-46c2-8a6b-58ae13e4d797	authenticated	authenticated	2043200198@maristabrasil.g12.br	$2a$10$Jm/b.H/eLMAgnJdr3es4V.CulajdryZf1zzHXv3FAe6usS2pEfYNa	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ANA CLARA MACÊDO MOREIRA SANTOS", "role": "aluno", "turma": "23C", "matricula": "2043200198"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4e73daad-756b-43c2-a4a1-ca0839f28945	authenticated	authenticated	2043150030@maristabrasil.g12.br	$2a$10$MlKMwoorVo/v0jkiz1Jeq.Z.4ASnW5yl.ZxMtqK27LJdWTYU41MZW	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "BERNARDO AQUINO BRANDÃO DE CASTILHO", "role": "aluno", "turma": "23C", "matricula": "2043150030"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1577cf1a-f56c-4fb5-879e-4b93255ff77f	authenticated	authenticated	2043260368@maristabrasil.g12.br	$2a$10$E0txpmiAyRAPaIBjSwRkhu7geF9o79ZYfTuPS/VsE8HPpJiRNbota	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "BERNARDO MIGUEL DRUMMOND DAIHA", "role": "aluno", "turma": "23C", "matricula": "2043260368"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2bc7aba6-8cc1-445f-ab48-3615c179202e	authenticated	authenticated	2043160156@maristabrasil.g12.br	$2a$10$GFQJekkFimdCdJxQqBnPdOWU52MB.GokPmUI6xtNke3zKKea8.aoy	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "CAUÊ NOVO MENDES", "role": "aluno", "turma": "23C", "matricula": "2043160156"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	9ab5f35a-7009-4e35-b3b9-004b08058bf3	authenticated	authenticated	2043140531@maristabrasil.g12.br	$2a$10$ynzAANRYyXWaYq03tlknguWOdMohgCDiUKZVAr4/zEi4a0BKIB61q	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "CLARA MONTEIRO SANTOS NEIVA", "role": "aluno", "turma": "23C", "matricula": "2043140531"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	64331c5f-ca06-47ef-a51d-7f0881d02679	authenticated	authenticated	2043250155@maristabrasil.g12.br	$2a$10$q/GHs8KQvCpOTZRV4h2dRuEnWl0esG4B4Ac3k.26pQGJuvF9AbJIy	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "DAVI COSTA ANTUNES", "role": "aluno", "turma": "23C", "matricula": "2043250155"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1f413de0-b217-4e4d-b996-34e16990a51d	authenticated	authenticated	2043190096@maristabrasil.g12.br	$2a$10$tWJPHa81/VBfhnQbtou1POq3rcUaQ9kKPUXLmSI8MM/4gBFsy163i	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ELLEN ANTONINI PALMA", "role": "aluno", "turma": "23C", "matricula": "2043190096"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	95471473-5cd7-4496-82ed-8f54eb35ea0d	authenticated	authenticated	2043220119@maristabrasil.g12.br	$2a$10$qZohxf7jkyMbN0zEdyVYlupAh46Zs1LPmNiww9s1BNHK5KpOxbOh2	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ENZO INNECCO SANTOS DONATI BARBOSA", "role": "aluno", "turma": "23C", "matricula": "2043220119"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	90b07974-e6ef-429d-8416-0cf7be5bafd4	authenticated	authenticated	2043140241@maristabrasil.g12.br	$2a$10$S5FHYSM4x3QPVUrChW/uh.ZEghAP.UZ2W0VoMZJ6Ujp4jif/Cv7yC	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "FERNANDA JÁUREGUI DE CARVALHO", "role": "aluno", "turma": "23C", "matricula": "2043140241"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5fbf9d7a-4646-45de-8afe-b0396ba7b5a4	authenticated	authenticated	2043240271@maristabrasil.g12.br	$2a$10$Q8ElcH4JT.TFzHl9.g9OuuxUQYSxZRk9PPUIwIQHnfPsAjnVvk51O	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "GABRIEL DE CASTRO RÊGO DE CARVALHO", "role": "aluno", "turma": "23C", "matricula": "2043240271"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3376a68c-fde7-42c1-ab4d-435fab9c41e9	authenticated	authenticated	2043120232@maristabrasil.g12.br	$2a$10$vjOaDvfUqBJIFTus9H.wJeXLHMhfrm357Q699gEQCFtCU4StMymcO	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "GUSTAVO SILVA DE OLIVEIRA", "role": "aluno", "turma": "23C", "matricula": "2043120232"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	129ba608-00c1-4472-87f5-9b780f7bb042	authenticated	authenticated	2043240292@maristabrasil.g12.br	$2a$10$8gvmtEW1PNAosilCX3Y8buy1JYv1RdRWMXM2YTrL90al30J1mzjHW	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "HELENA MIRANDA LOLATO", "role": "aluno", "turma": "23C", "matricula": "2043240292"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3d4a383e-07c2-416d-b39b-a8714fe003e1	authenticated	authenticated	2043220021@maristabrasil.g12.br	$2a$10$4ssthVHdHlOI0yoDN2MOreWGz/HhYW3DGpY6cWn7SS60CnEu9FMX.	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "PEDRO LIMA SARMANHO", "role": "aluno", "turma": "23C", "matricula": "2043220021"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	71abdf5c-4796-471c-a105-a8776a08246d	authenticated	authenticated	2043200132@maristabrasil.g12.br	$2a$10$097yhDnUF8PYAIU2Qccfw..GsSd6P3gm9d1cMEUVlSY1G2odCGmWm	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "SAMUEL VAZ COUTINHO", "role": "aluno", "turma": "23C", "matricula": "2043200132"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	83139a8d-9c50-409e-a661-e93a3066ac91	authenticated	authenticated	2043160020@maristabrasil.g12.br	$2a$10$oyRKQe0KPRSJdMrylmD8fur1pWso4JT25SvLiBadnLskP20WlYy8C	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "SARAH BRANDÃO XUDRÉ BRITO", "role": "aluno", "turma": "23C", "matricula": "2043160020"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	eb36c257-5eb3-4860-916a-608ab90a4a6a	authenticated	authenticated	2043150303@maristabrasil.g12.br	$2a$10$2e2OYpd9ZhjxyPZg2HUZvu6VXW4veho1BPbgrtcxvw/EWCpQjLTrS	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "THIAGO QUEIROZ RIBEIRO", "role": "aluno", "turma": "23C", "matricula": "2043150303"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	26999db5-99e7-4da3-ac85-758ec7078e0d	authenticated	authenticated	2043150082@maristabrasil.g12.br	$2a$10$sA9TKHE5dyGdRXE20n0sTO9PNTxvWIWwFrMv6F9zg3IvlSnBdDJWm	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "ISABELA PORTO AITA BITTENCOURT", "role": "aluno", "turma": "23C", "matricula": "2043150082"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f003a689-aff9-4fbc-940f-694a7fe56f29	authenticated	authenticated	2043250318@maristabrasil.g12.br	$2a$10$/YTDo8NPG63RvNrI84U9He2f1DdYtdBCm63i1GmBYzWjWAREYPn9e	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JOÃO BARROS FONSECA", "role": "aluno", "turma": "23C", "matricula": "2043250318"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	cf27ae3d-ee82-44f0-80ba-eb5931dd6f55	authenticated	authenticated	2043200173@maristabrasil.g12.br	$2a$10$UKfGvFBb//vXZ9/FjKefxuk1qvHMXxQgR2yDlhB73LP3fRVdurXQi	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JOÃO PEDRO MIZIARA ROCHA", "role": "aluno", "turma": "23C", "matricula": "2043200173"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	fe88150a-e1eb-4742-95a9-d7e2ce5b62c0	authenticated	authenticated	2043200223@maristabrasil.g12.br	$2a$10$0tUIFOuyRzq0IU0gASlPLOhTLdJZ9S1aRxaDhuAimkz4vG.TLIYLq	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "JULIA FERREIRA MIRANDA", "role": "aluno", "turma": "23C", "matricula": "2043200223"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	d5c384f2-4dff-4508-ba02-f81c5e7eaf02	authenticated	authenticated	2043230169@maristabrasil.g12.br	$2a$10$4jV4XQTjzxhUO9o.BsKn2.ErzGET9KG3Nwwt8xItkgRkvU2QWx8NW	2026-05-22 21:25:43.933275+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"nome": "LÍVIA COSTA BERNARDO", "role": "aluno", "turma": "23C", "matricula": "2043230169"}	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: badges_conquistados; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.badges_conquistados (id, aluno_id, badge_id, conquistado_em) FROM stdin;
b09feb7f-63df-4334-847f-7c380df3311c	00000000-0000-0000-0000-000000000099	primeiro_acesso	2026-05-23 19:02:30.384673+00
\.


--
-- Data for Name: notificacoes_professor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notificacoes_professor (id, professor_id, tipo, referencia_id, mensagem, lida, created_at) FROM stdin;
\.


--
-- Data for Name: perfis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.perfis (id, matricula, nome, turma, email, role, senha_trocada, ativo, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000099	TESTE01	ALUNO TESTE	23A	teste@maristabrasil.g12.br	aluno	t	t	2026-05-23 19:00:59.36899+00	2026-05-23 19:00:59.36899+00
5f90fcd7-8d06-4653-bfb3-2c25cfc092d9	2043260353	ÁLVARO AMORIM CUNHA MARTINS	23A	2043260353@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
92e05c61-74a1-401d-8d52-ea0f420e87a8	2043130157	CAROLINA BORGES FURTADO NEVES	23A	2043130157@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
a46db1b2-ccc3-488e-91af-0a98d7730adc	2043160370	FERNANDA RIBEIRO LIMA	23A	2043160370@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
92462d59-6c01-4e39-8695-b8a468e87617	2043220170	FRANCISCO PEREIRA DE SOUSA SILVEIRA	23A	2043220170@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
83125671-5a73-4d97-bde1-0bf31ecee37d	2043160234	GIOVANNA FERNANDES ABEN ATHAR	23A	2043160234@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
fd86a8c1-1bd2-4b9d-b79e-ab7f65bdeb03	2043150245	GUSTAVO HENRIQUE MOTTA MOREIRA	23A	2043150245@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
7359f307-9094-4f06-b763-621c309dc921	2043250326	ISADORA GUIMARÃES MADRUGA SINOTT LOPES	23A	2043250326@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
bd9c30b5-ea7f-48a4-a530-a33d38122d50	2043200081	JOÃO PEDRO NOBRE REIS	23A	2043200081@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
7cf5e3e8-7e5d-42f3-b40d-ab974aa5b452	2043250321	JOÃO VITOR LIMA ANDRADE	23A	2043250321@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
09be4886-2692-4904-9db3-8278fbe25010	2043240189	JÚLIO RAMOS DE SOUZA E SILVA	23A	2043240189@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
5dd13d2e-ffa2-4fe6-bf8f-ba72b010f9d5	2043220181	LETÍCIA DE AZEVEDO E OLIVEIRA	23A	2043220181@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
4d41e102-8047-4aea-ba49-2262cbc05d30	2043120116	LETÍCIA VAZ DA COSTA RIBEIRO	23A	2043120116@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
5c716e9c-b1e4-4da8-8b6c-66e63649ae44	2043240019	LOUISE REZENDE DE OLIVEIRA	23A	2043240019@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
9297f341-0235-433e-a66c-5ca6bff0411a	2043140164	LUCAS AKIRA YOSHIMINE SILVA	23A	2043140164@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
92b7acff-0598-4d6b-9d9f-5a8ee2cff04e	2043240186	LUCAS CARVALHO SILVEIRA	23A	2043240186@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
4bdfea0d-31ba-4f06-80f7-3854d27d6a43	2043250119	MARIA FERNANDA BEDIN WELTER	23A	2043250119@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
2773bc2f-8365-43d6-a173-54dbe1a3713d	2043170184	MARIA LUISA CARVALHO MESQUITA	23A	2043170184@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
84794059-1303-4c66-84e5-638b287ddc74	2043170273	MARIANA DE ARAGÃO SANJAD	23B	2043170273@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
aa937fb5-9a49-4e67-8bb5-e0f7a594c41d	2043190290	MEL AVILA MALLAB	23B	2043190290@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
a9751085-e9a8-4cb0-97ef-1ed8cb247ce4	2043250217	MARIA LUIZA PIMENTA DE SOUSA	23A	2043250217@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
f5cf157c-e6cd-4e3c-9864-46878fad13ba	2043230167	MARIA THAYLA OLIVEIRA LACERDA	23A	2043230167@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
30cbe8c9-4c3d-45a8-9a7b-893ba0497e89	2043240003	MARIANA BEATRIZ SOARES COELHO DA COSTA	23A	2043240003@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
2099c68d-f84b-474a-b6c0-fedb9b1f2dbe	2043120068	NÍCOLAS TARSITANO NOBRE	23A	2043120068@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
5207f053-a1a3-4224-9a4a-15aa27ab27ce	2043230175	NINA HARTMANN E SÁ	23A	2043230175@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
674617f0-5753-4bfd-af59-9e928db0e357	2043240393	OTÁVIO ALVES GALVÃO NETO	23A	2043240393@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
4ec48451-e8a7-41d8-9a25-b14fb6712661	2043150381	PEDRO ROMANO PONTES DE FARIA CAMPOS	23A	2043150381@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
9d1f13c8-6094-4a74-9f29-a7cc65d4daf1	2043250219	REBECA MOURA MARTINS	23A	2043250219@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
f2dc6958-ad52-4c4f-aa62-11e985a625b8	2043240197	RENERSON KOHLER FEDALTO FILHO	23A	2043240197@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
69b57770-bdd8-45d6-aca7-cb686c71c233	2043240297	SELTON FELIPE DA SILVA FURTADO	23A	2043240297@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
48f0060b-5248-4868-9d8e-7844ab57d27b	2043160237	VALENTINA MESQUITA FIGUEIREDO	23A	2043160237@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
042e9758-bae0-49e3-a53d-cd98b75d9a39	2043240364	VALENTINA VALE DO MONTE ROSA	23A	2043240364@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
6c8e4fff-fc9a-4a33-8d68-f4a86b381339	2043150218	ANA SOPHIA SOUSA GUIMARÃES	23B	2043150218@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
e7382a51-1499-4d35-9f4d-42731fcf6c49	2043240313	ARTUR ROTH BRASIL FERREIRA	23B	2043240313@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
439eb8e6-59d0-4f2f-b210-f4da6ad5efa2	2043200125	BRUNO LUSTZ RODRIGUES	23B	2043200125@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
739bd399-855c-4043-b4b2-e2418079c7bf	2043150379	CAMILA OKADA LINARES SANTOS	23B	2043150379@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
7ff1cfc4-7ff0-4013-b032-369ce8d25f0b	2043200190	CLARA TAVARES COMETTI	23B	2043200190@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
caf69fa5-7a26-4c5d-b83d-309ab92d11b0	2043140047	FERNANDA SANT´ANNA DE ANDRADE	23B	2043140047@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
f135bb07-4559-4c15-9c42-39851a743b6c	2043230202	FLOR MARIANA ENCARNAÇÃO CIDADE	23B	2043230202@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
f14fe5d9-8dd1-4dd1-ab7b-b8326f65a534	2043200098	FRANCISCO ALBERT KAHN STEPHAN	23B	2043200098@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
dd050ead-d327-48a6-84a8-e37e46a63a51	2043190218	FRANCISCO LLERAS MELLO	23B	2043190218@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
90efcdd5-0b92-42e7-96d7-bfecbd477eb0	2043240385	GABRIEL VÖLKER LACERDA	23B	2043240385@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
ef0cd2ed-b9ad-4e37-b2eb-df7282d13521	2043150242	GUILHERME DE SOUZA NOGUEIRA DE ANDRADE	23B	2043150242@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
5c69f88a-f85a-4b09-a0f8-385e48ad7545	2043230132	GUSTAVO MENDES MAGALHÃES	23B	2043230132@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
a7c06b24-9822-4284-9ee1-cf1ca4359826	2043230196	IARA TEIXEIRA SAUERBRONN	23B	2043230196@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
e6470169-b326-46a5-989a-878256637114	2043150084	IGOR BALDUINO DE GUSMÃO	23B	2043150084@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
28ee21dd-7885-4a15-9981-d04b6aafa1c3	2043230124	IVANA MEI LEITE PEREIRA	23B	2043230124@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
e46f7fac-97c5-4aa6-abd3-1757993bde9b	2043140315	JOÃO PEDRO MAIA TEIXEIRA	23B	2043140315@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
3effd2a9-babf-4354-bb8c-11eaaff840d1	2043150310	JÚLIA LEMES SILVA	23B	2043150310@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
7d5384a9-b88b-4987-84cc-f821434dca1e	2043250293	JÚLIA SANTOS FONTINELE E SILVA	23B	2043250293@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
21ac53ee-2851-4be1-83f5-d81ff829621a	2043240020	LAÍS REZENDE DE OLIVEIRA	23B	2043240020@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
19cb15cb-cd51-4223-8d70-ba18545777d3	2043190025	LORENA ALVES REINA ALVES	23B	2043190025@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
cc10e0a1-89cb-42b1-bf8c-c396346c2e9a	2043160304	LUÍSA MARIM DOS SANTOS	23B	2043160304@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
f764f07f-ac16-4458-bddf-961c3a068bba	2043240386	LUIZA NÓBREGA REZENDE CORTEZ	23B	2043240386@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
3e334047-c1e3-49ee-8a80-351bd12b15eb	2043250320	MARIA EDUARDA BARBOSA LIMA	23B	2043250320@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
f166e388-c817-4dfb-90b1-91ce3f409af5	2043220089	MARIA EDUARDA GUIMARÃES BEZERRA DE MENEZES	23B	2043220089@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
1d6225f2-361d-4a21-8ee6-9ce6abd08b6e	PROF002	ROSELY BRAZ	\N	rosely.braz@maristabrasil.org	professor	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
1d9b1a3b-dabe-43cb-ba5a-7878d7d9c1ba	2043240017	MATEUS CRISTIANO QUEIROZ DA SILVA GOMES	23B	2043240017@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
a62219d6-10a8-4676-a048-6aa258c7b50c	2043140375	MATEUS DE OLIVEIRA CARVALHO	23B	2043140375@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
8b1a0f39-934e-4a17-9b3d-15fd50f3cb94	2043260324	MÔNICA GUIMARÃES MACEDO	23B	2043260324@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
4a403d53-61c3-49ea-a881-705cbe397dcf	2043160214	PEDRO HENRIQUE SANTOS DE ALMEIDA	23B	2043160214@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
6af419cf-6199-4584-9b43-aa78faad995b	2043250308	SANDRA REGINA SOUZA DOS SANTOS	23B	2043250308@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
7606a6f5-17c5-4b67-945a-4772fd826a01	2043240318	TERESA FERNANDES MONDONI	23B	2043240318@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
62a9266b-1027-4502-b1ae-8b902dfe7fec	2043130162	THEO DE LUCENA CASARIN DALMAS	23B	2043130162@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
89e6e076-438c-4c5b-87ce-b559ae9cc66c	2043260346	ANA AROSO SANTOS	23C	2043260346@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
b3693735-c3f7-46c2-8a6b-58ae13e4d797	2043200198	ANA CLARA MACÊDO MOREIRA SANTOS	23C	2043200198@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
4e73daad-756b-43c2-a4a1-ca0839f28945	2043150030	BERNARDO AQUINO BRANDÃO DE CASTILHO	23C	2043150030@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
1577cf1a-f56c-4fb5-879e-4b93255ff77f	2043260368	BERNARDO MIGUEL DRUMMOND DAIHA	23C	2043260368@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
2bc7aba6-8cc1-445f-ab48-3615c179202e	2043160156	CAUÊ NOVO MENDES	23C	2043160156@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
9ab5f35a-7009-4e35-b3b9-004b08058bf3	2043140531	CLARA MONTEIRO SANTOS NEIVA	23C	2043140531@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
64331c5f-ca06-47ef-a51d-7f0881d02679	2043250155	DAVI COSTA ANTUNES	23C	2043250155@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
1f413de0-b217-4e4d-b996-34e16990a51d	2043190096	ELLEN ANTONINI PALMA	23C	2043190096@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
95471473-5cd7-4496-82ed-8f54eb35ea0d	2043220119	ENZO INNECCO SANTOS DONATI BARBOSA	23C	2043220119@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
90b07974-e6ef-429d-8416-0cf7be5bafd4	2043140241	FERNANDA JÁUREGUI DE CARVALHO	23C	2043140241@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
5fbf9d7a-4646-45de-8afe-b0396ba7b5a4	2043240271	GABRIEL DE CASTRO RÊGO DE CARVALHO	23C	2043240271@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
3376a68c-fde7-42c1-ab4d-435fab9c41e9	2043120232	GUSTAVO SILVA DE OLIVEIRA	23C	2043120232@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
129ba608-00c1-4472-87f5-9b780f7bb042	2043240292	HELENA MIRANDA LOLATO	23C	2043240292@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
26999db5-99e7-4da3-ac85-758ec7078e0d	2043150082	ISABELA PORTO AITA BITTENCOURT	23C	2043150082@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
f003a689-aff9-4fbc-940f-694a7fe56f29	2043250318	JOÃO BARROS FONSECA	23C	2043250318@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
cf27ae3d-ee82-44f0-80ba-eb5931dd6f55	2043200173	JOÃO PEDRO MIZIARA ROCHA	23C	2043200173@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
fe88150a-e1eb-4742-95a9-d7e2ce5b62c0	2043200223	JULIA FERREIRA MIRANDA	23C	2043200223@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
d5c384f2-4dff-4508-ba02-f81c5e7eaf02	2043230169	LÍVIA COSTA BERNARDO	23C	2043230169@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
505e2654-511a-4fad-852c-10c1a20577b9	2043240330	MAITÊ CAVALCANTE LIMA GARBINI DE FIGUEIREDO	23C	2043240330@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
f482e70c-94ec-4a48-9699-a47315a5ec3a	2043220072	MANUELA MONTÓN DA COSTA	23C	2043220072@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
bff8f563-6312-4c35-bd6c-bf150a598567	2043240217	MARIA CLARA LOPES DE OLIVEIRA SILVA	23C	2043240217@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
e6731988-19f7-4a6d-a583-562978836228	2043150319	MARIA CLARA SOUZA LAROCCA RIGAILO	23C	2043150319@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
1b52a101-47f5-4eca-b6f1-d9c856a9377d	2043160385	MARINA ROCHA CABRAL	23C	2043160385@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
3d4a383e-07c2-416d-b39b-a8714fe003e1	2043220021	PEDRO LIMA SARMANHO	23C	2043220021@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
71abdf5c-4796-471c-a105-a8776a08246d	2043200132	SAMUEL VAZ COUTINHO	23C	2043200132@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
83139a8d-9c50-409e-a661-e93a3066ac91	2043160020	SARAH BRANDÃO XUDRÉ BRITO	23C	2043160020@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
eb36c257-5eb3-4860-916a-608ab90a4a6a	2043150303	THIAGO QUEIROZ RIBEIRO	23C	2043150303@maristabrasil.g12.br	aluno	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
80d358a7-79b3-47bd-9a81-c58e9c5cc5d7	PROF003	JOÃO BRUNO	\N	joao.bruno@maristabrasil.org	professor	f	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:05:16.546416+00
f323e9ea-5121-4d6b-b39e-a0029d45b90b	PROF001	DEYKO TEIXEIRA	\N	deyko.teixeira@maristabrasil.org	professor	t	t	2026-05-22 21:25:43.933275+00	2026-05-22 23:11:18.622779+00
\.


--
-- Data for Name: pontuacao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pontuacao (id, aluno_id, pontos_bio, pontos_quim, pontos_fis, pontos_simulado, pontos_bonus, pontos_total, streak_atual, streak_maximo, questoes_respondidas, questoes_corretas, updated_at) FROM stdin;
f0df6b91-e6d5-40a3-90fe-afcd525f775b	f323e9ea-5121-4d6b-b39e-a0029d45b90b	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
75b8ccac-ae28-48c9-a7e7-605efe95893b	1d6225f2-361d-4a21-8ee6-9ce6abd08b6e	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
9fa3f862-864c-47f3-94cb-b912c51e94cd	80d358a7-79b3-47bd-9a81-c58e9c5cc5d7	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
b07b9757-be27-486a-95c2-7424043bb1bf	5f90fcd7-8d06-4653-bfb3-2c25cfc092d9	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
b36e5b46-07af-4a65-abb2-e5f24cdc92e8	92e05c61-74a1-401d-8d52-ea0f420e87a8	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
bd4a952b-c2bb-4ee6-8309-d18e15e87606	a46db1b2-ccc3-488e-91af-0a98d7730adc	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
ecfb43ac-2af4-4ba5-81eb-011cbefe57cd	92462d59-6c01-4e39-8695-b8a468e87617	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
0f1e2fe6-e5f0-4c4c-82a5-bbc9f91e8cfe	83125671-5a73-4d97-bde1-0bf31ecee37d	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
f7b06224-3957-4843-9bc9-ad69bd496fdb	fd86a8c1-1bd2-4b9d-b79e-ab7f65bdeb03	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
6fef627b-80f8-4f1b-8e40-1596513412a1	7359f307-9094-4f06-b763-621c309dc921	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
f9075e4f-2d53-49bd-916f-4cc34d480e9d	bd9c30b5-ea7f-48a4-a530-a33d38122d50	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
457bf9cd-ce79-434c-bd97-2329651861ff	7cf5e3e8-7e5d-42f3-b40d-ab974aa5b452	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
7e63f0a0-276e-4fe3-8cd4-6869de332950	09be4886-2692-4904-9db3-8278fbe25010	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
5d393d6c-c73b-481a-b682-160e9cbaded5	5dd13d2e-ffa2-4fe6-bf8f-ba72b010f9d5	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
8c17240b-1eae-4f6b-a0b2-d9f4f12ab5d5	4d41e102-8047-4aea-ba49-2262cbc05d30	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
8ca313a5-88c3-4b5f-bd17-22daa70c2815	5c716e9c-b1e4-4da8-8b6c-66e63649ae44	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
fcb0cbdb-820e-43c5-8687-88543a894735	9297f341-0235-433e-a66c-5ca6bff0411a	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
597c73a5-b59f-4ec7-b166-e975eb3bdd5a	92b7acff-0598-4d6b-9d9f-5a8ee2cff04e	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
acebef87-50a2-4f3f-8c9b-ed701079a48d	4bdfea0d-31ba-4f06-80f7-3854d27d6a43	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
56501b48-24a9-46cb-8094-3c914d62bc62	2773bc2f-8365-43d6-a173-54dbe1a3713d	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
898da56d-e09c-4216-9f23-147e550c2162	a9751085-e9a8-4cb0-97ef-1ed8cb247ce4	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
1dcd0714-20b0-4912-a963-b36cbcea3395	f5cf157c-e6cd-4e3c-9864-46878fad13ba	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
6233462e-a4fd-44e1-ba8b-e09f528dd165	30cbe8c9-4c3d-45a8-9a7b-893ba0497e89	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
6bbcf0fd-86a4-466d-9aef-c2a8d6b901b9	2099c68d-f84b-474a-b6c0-fedb9b1f2dbe	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
d7625d3c-ce6c-44fe-89f8-4241128f5548	5207f053-a1a3-4224-9a4a-15aa27ab27ce	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
6ec2c286-4254-4bce-b729-845742b3ff93	674617f0-5753-4bfd-af59-9e928db0e357	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
384ab9be-b5b1-46a1-95d4-2f4186436752	4ec48451-e8a7-41d8-9a25-b14fb6712661	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
eb59bc69-0994-4ef9-b981-c640fa8d564a	9d1f13c8-6094-4a74-9f29-a7cc65d4daf1	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
2a6a88d9-5266-407c-a82b-295bfc77e9b4	f2dc6958-ad52-4c4f-aa62-11e985a625b8	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
eccd7cb9-221f-4988-8507-b3f5ae23d34e	69b57770-bdd8-45d6-aca7-cb686c71c233	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
f6285308-afc4-4bf1-b5c3-b10aafecbf3f	48f0060b-5248-4868-9d8e-7844ab57d27b	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
27709e2f-b693-4698-9189-0740d454ebb2	042e9758-bae0-49e3-a53d-cd98b75d9a39	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
837f1778-8776-4bf1-8e66-73bdf269ba2f	6c8e4fff-fc9a-4a33-8d68-f4a86b381339	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
e563dc98-59c0-4aa9-a2a0-bf5a70249304	e7382a51-1499-4d35-9f4d-42731fcf6c49	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
fd9cd771-844b-4396-85d2-4f8c28d74f31	439eb8e6-59d0-4f2f-b210-f4da6ad5efa2	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
d1a062b1-6f71-43df-8c3d-a8e204e65e76	739bd399-855c-4043-b4b2-e2418079c7bf	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
3648f43c-920c-447c-9f00-71cc2bc54e0f	7ff1cfc4-7ff0-4013-b032-369ce8d25f0b	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
00d65c09-aa2d-4753-9f61-e644fdfad078	caf69fa5-7a26-4c5d-b83d-309ab92d11b0	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
e2ef5710-1445-4645-aaee-16154c1a869d	f135bb07-4559-4c15-9c42-39851a743b6c	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
e5ff490c-5fe0-4c6c-860e-a946ab20f681	f14fe5d9-8dd1-4dd1-ab7b-b8326f65a534	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
3568a00f-a7f6-4e46-b407-52b95f8ce5c5	dd050ead-d327-48a6-84a8-e37e46a63a51	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
870dcba4-435a-49de-8da1-a120ea018167	90efcdd5-0b92-42e7-96d7-bfecbd477eb0	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
577f4470-7b97-4fea-994a-aa45c4fc172b	ef0cd2ed-b9ad-4e37-b2eb-df7282d13521	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
e25ddb4e-9627-4e6f-8c2d-0167a88db979	5c69f88a-f85a-4b09-a0f8-385e48ad7545	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
33882dbd-98d8-4091-9cdd-27d775a067f4	a7c06b24-9822-4284-9ee1-cf1ca4359826	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
ec282d84-d68f-4704-8cbf-1cf56a2aa76e	e6470169-b326-46a5-989a-878256637114	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
6bc9b923-27a5-4522-a913-cd8afabfae32	28ee21dd-7885-4a15-9981-d04b6aafa1c3	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
2b51c9bc-0308-4009-a5ef-fc9e61e3e679	e46f7fac-97c5-4aa6-abd3-1757993bde9b	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
be27d825-7d16-436e-a593-bf3781aed3c2	3effd2a9-babf-4354-bb8c-11eaaff840d1	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
1ae0d372-b448-4c4d-a4e0-70cd3414b0b2	7d5384a9-b88b-4987-84cc-f821434dca1e	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
edf2de11-8aea-4372-88ac-35276894ed85	21ac53ee-2851-4be1-83f5-d81ff829621a	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
fc8b0907-3ddf-42e5-ae04-877043c5a64c	19cb15cb-cd51-4223-8d70-ba18545777d3	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
033fd135-5728-4dea-94de-e40f44e21433	cc10e0a1-89cb-42b1-bf8c-c396346c2e9a	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
1b253f68-aa8d-4fa5-b899-1baf6de55171	f764f07f-ac16-4458-bddf-961c3a068bba	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
83c8a549-8ec6-45bc-921f-3d1f47829836	3e334047-c1e3-49ee-8a80-351bd12b15eb	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
29884b1c-1eb2-42b9-b0da-db03b28cea3c	f166e388-c817-4dfb-90b1-91ce3f409af5	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
8cbc9271-53df-4201-a72f-055218daf5f6	84794059-1303-4c66-84e5-638b287ddc74	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
a65fb4b9-1d2e-499f-a20e-a0a69463f4bb	1d9b1a3b-dabe-43cb-ba5a-7878d7d9c1ba	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
3d68945f-a3d0-4812-8537-801b60972202	a62219d6-10a8-4676-a048-6aa258c7b50c	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
318c79dd-48e6-4046-aa41-63e1514e9631	aa937fb5-9a49-4e67-8bb5-e0f7a594c41d	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
e635194b-a363-42f8-a6e6-6b40fd510ddd	8b1a0f39-934e-4a17-9b3d-15fd50f3cb94	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
c8c0c2af-7f3a-4f7e-ba25-019c4ec2f471	4a403d53-61c3-49ea-a881-705cbe397dcf	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
8967cfa2-99e7-4fdb-9eb3-5f66f07939ef	6af419cf-6199-4584-9b43-aa78faad995b	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
e5a93653-1fd1-4478-b40f-63e6cbc7a2d5	7606a6f5-17c5-4b67-945a-4772fd826a01	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
40d09b75-534d-44ab-ada8-f687a5cf1393	62a9266b-1027-4502-b1ae-8b902dfe7fec	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
6fbf5e9a-87ce-49a9-8d47-8b1bfce6709b	89e6e076-438c-4c5b-87ce-b559ae9cc66c	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
d80e4ec3-07ad-442e-81d0-1588fbba9a03	b3693735-c3f7-46c2-8a6b-58ae13e4d797	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
e5f4ee88-a665-4924-87b1-7460cd8a0e7d	4e73daad-756b-43c2-a4a1-ca0839f28945	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
46f948ce-7624-4134-a284-0c5cccc9e660	1577cf1a-f56c-4fb5-879e-4b93255ff77f	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
7078b173-8b96-42bf-b006-622985635dab	2bc7aba6-8cc1-445f-ab48-3615c179202e	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
620122c1-cb92-43c7-898f-81e2b1e031c9	9ab5f35a-7009-4e35-b3b9-004b08058bf3	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
3f3ebbd9-f588-48bc-bfea-1f64a447d945	64331c5f-ca06-47ef-a51d-7f0881d02679	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
1f16e88c-6fda-4887-9885-2aed9bbcbb70	1f413de0-b217-4e4d-b996-34e16990a51d	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
10203c12-5ac9-4b70-ab1f-e7ec29c9b9e5	95471473-5cd7-4496-82ed-8f54eb35ea0d	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
aec083dc-08bf-4231-b71e-7e4a96432d9b	90b07974-e6ef-429d-8416-0cf7be5bafd4	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
2ca267bb-3d8e-4d19-986c-830510c3793a	5fbf9d7a-4646-45de-8afe-b0396ba7b5a4	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
5adc28ce-5c35-45e8-b75b-59a5da23bb17	3376a68c-fde7-42c1-ab4d-435fab9c41e9	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
bf184253-4c5d-4632-a3cd-ac04824adc24	129ba608-00c1-4472-87f5-9b780f7bb042	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
f17b064b-15b8-4bfc-8952-6255da042e98	26999db5-99e7-4da3-ac85-758ec7078e0d	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
9cdb9c4e-09bc-4560-b8b4-d43c1d7b34c3	f003a689-aff9-4fbc-940f-694a7fe56f29	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
b14644f1-2423-4669-927b-7c17e94d2b87	cf27ae3d-ee82-44f0-80ba-eb5931dd6f55	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
332cfa0d-08bc-4375-ab00-966bc7c2c055	fe88150a-e1eb-4742-95a9-d7e2ce5b62c0	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
c4a8195f-f14f-4e96-9728-ecdb3616f1df	d5c384f2-4dff-4508-ba02-f81c5e7eaf02	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
330fdb5c-7126-40f9-9bc0-2b761630f8fa	505e2654-511a-4fad-852c-10c1a20577b9	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
ecc59667-2f82-454d-b127-29b4fc11b58c	f482e70c-94ec-4a48-9699-a47315a5ec3a	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
e92b8562-730c-44c0-a005-08610246244a	bff8f563-6312-4c35-bd6c-bf150a598567	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
5822c953-6212-41ee-a4eb-15b248a42a45	e6731988-19f7-4a6d-a583-562978836228	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
f7c29e1b-b960-4a63-9b6b-9ec53554f7c4	1b52a101-47f5-4eca-b6f1-d9c856a9377d	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
f3ca65be-6452-492d-8f6d-a6f00ca392fb	3d4a383e-07c2-416d-b39b-a8714fe003e1	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
db0d7fb1-1995-4728-b960-5c5a9bf5a7d0	71abdf5c-4796-471c-a105-a8776a08246d	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
2eb7d6a8-7780-4ce2-988c-f1ba613df0d3	83139a8d-9c50-409e-a661-e93a3066ac91	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
11735ebc-a16d-4c37-9ead-c97677263e52	eb36c257-5eb3-4860-916a-608ab90a4a6a	0	0	0	0	0	0	0	0	0	0	2026-05-22 21:25:43.933275+00
1251876d-3450-4894-84b8-7a6ed1d51f83	00000000-0000-0000-0000-000000000099	0	0	0	0	0	0	0	0	0	0	2026-05-23 20:45:28.832939+00
\.


--
-- Data for Name: progresso_revisao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.progresso_revisao (id, aluno_id, disciplina, total_questoes, acertos, concluida, percentual, ultima_atividade, created_at, updated_at) FROM stdin;
e04daad1-5880-462d-8742-69fd67c21fae	f323e9ea-5121-4d6b-b39e-a0029d45b90b	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
27798397-a4a7-4e72-b37d-52f4b9d04a57	f323e9ea-5121-4d6b-b39e-a0029d45b90b	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
21e8c8c7-a9ce-4dfa-b42a-ebd44052157d	f323e9ea-5121-4d6b-b39e-a0029d45b90b	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
3d2f1687-7f44-4c36-8f31-02fc077c9eab	1d6225f2-361d-4a21-8ee6-9ce6abd08b6e	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6a50b124-8410-49f0-8691-0c7acf00ecd3	1d6225f2-361d-4a21-8ee6-9ce6abd08b6e	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
69a0597b-a0e1-421f-a508-4315783c3345	1d6225f2-361d-4a21-8ee6-9ce6abd08b6e	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
820eb9dd-69a3-4074-9017-9b5abe57e848	80d358a7-79b3-47bd-9a81-c58e9c5cc5d7	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f69a9f8b-6837-4209-bd8f-075e88030eb6	80d358a7-79b3-47bd-9a81-c58e9c5cc5d7	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a085068f-1120-4bc3-bd79-19c3d97626ea	80d358a7-79b3-47bd-9a81-c58e9c5cc5d7	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
2b9671d9-db44-4f8a-b9ee-8f433b96ab98	5f90fcd7-8d06-4653-bfb3-2c25cfc092d9	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
be8f2e45-0fae-40a7-a958-393b959b0cec	5f90fcd7-8d06-4653-bfb3-2c25cfc092d9	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
1d5f48f7-e459-41ef-8a7d-91a6722bb700	5f90fcd7-8d06-4653-bfb3-2c25cfc092d9	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f106b0e3-2375-4e93-b7d3-8099a24354a1	92e05c61-74a1-401d-8d52-ea0f420e87a8	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
68e9c5a7-345f-45a9-a5b5-cafcd117aed5	92e05c61-74a1-401d-8d52-ea0f420e87a8	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e0d7260c-399f-45bd-9bb6-e601ca76ca6b	92e05c61-74a1-401d-8d52-ea0f420e87a8	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
78c9925d-a8fa-4c83-ba2b-bd8eb8c658bc	a46db1b2-ccc3-488e-91af-0a98d7730adc	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
552edef3-b42f-46f3-bcd0-ea95e971cdf7	a46db1b2-ccc3-488e-91af-0a98d7730adc	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9915bce8-cb91-4187-aca5-3fda53afd26b	a46db1b2-ccc3-488e-91af-0a98d7730adc	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b1f834b0-0f1a-41c2-a6d0-0ba1e3e650b4	92462d59-6c01-4e39-8695-b8a468e87617	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a6f87c19-5a2b-4c4d-a015-78be19af589a	92462d59-6c01-4e39-8695-b8a468e87617	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
88f8bbc7-0cc5-4856-bf29-d798ccc86b17	92462d59-6c01-4e39-8695-b8a468e87617	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
87e5301d-ba3c-4046-8fbb-74d6879d5a5b	83125671-5a73-4d97-bde1-0bf31ecee37d	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5559ba3f-f53e-4c38-a84a-c0a15b6ce0a4	83125671-5a73-4d97-bde1-0bf31ecee37d	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
85988eba-73c7-4878-90eb-dfc51d98d3de	83125671-5a73-4d97-bde1-0bf31ecee37d	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d03e5127-2c2f-41fd-b658-3072103081cc	fd86a8c1-1bd2-4b9d-b79e-ab7f65bdeb03	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b2a05d10-fe5f-4c90-9b25-c67215e1f9c9	fd86a8c1-1bd2-4b9d-b79e-ab7f65bdeb03	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
23f36d20-a269-4117-a61b-e68e7c9659d9	fd86a8c1-1bd2-4b9d-b79e-ab7f65bdeb03	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
25775647-4591-42a6-ac19-72c9449e9b97	7359f307-9094-4f06-b763-621c309dc921	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5444dd6c-d669-49b5-a412-39295a20b8ee	7359f307-9094-4f06-b763-621c309dc921	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f751ae1b-ebd8-4375-b422-f6b579dc696e	7359f307-9094-4f06-b763-621c309dc921	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
477ca0b5-63bd-4384-ba2a-cdeef1e3bc70	bd9c30b5-ea7f-48a4-a530-a33d38122d50	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d406e72b-a92b-431f-bbe9-8dae0139dc72	bd9c30b5-ea7f-48a4-a530-a33d38122d50	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
8878605a-4d83-4e0b-8fab-17b4570b468d	bd9c30b5-ea7f-48a4-a530-a33d38122d50	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
47b8b4f0-14fd-4d6d-9a57-aa842a38de36	7cf5e3e8-7e5d-42f3-b40d-ab974aa5b452	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
c9d8f898-d802-417b-842d-608c32c52474	7cf5e3e8-7e5d-42f3-b40d-ab974aa5b452	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e3e97ad8-0980-47e4-be32-94e3cf5f1eb4	7cf5e3e8-7e5d-42f3-b40d-ab974aa5b452	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
cb6f9722-fbc5-4039-8a9e-65d853c1ced0	09be4886-2692-4904-9db3-8278fbe25010	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
cac19008-1601-445e-a38a-b0a3d80dbff6	09be4886-2692-4904-9db3-8278fbe25010	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
09db7d8d-aa68-422b-a149-548e60ce6568	09be4886-2692-4904-9db3-8278fbe25010	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
cd63990f-00cf-4a21-b6c8-4164e50afe13	5dd13d2e-ffa2-4fe6-bf8f-ba72b010f9d5	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
44370a91-6258-462e-9ec6-ade5aa650f7b	5dd13d2e-ffa2-4fe6-bf8f-ba72b010f9d5	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
4bb8a129-a8ff-457e-b9fc-44e3f1aa4887	5dd13d2e-ffa2-4fe6-bf8f-ba72b010f9d5	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
fa4a3191-b8dd-42ed-a6bc-3f9016d3a734	4d41e102-8047-4aea-ba49-2262cbc05d30	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
33afc525-da36-460c-b7e0-bab84b108b93	4d41e102-8047-4aea-ba49-2262cbc05d30	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f322f04d-c50d-4a7a-9da0-06c75c53dad5	4d41e102-8047-4aea-ba49-2262cbc05d30	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
564b4d11-7d15-465b-ac61-121247708442	5c716e9c-b1e4-4da8-8b6c-66e63649ae44	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
1de6fbf6-5833-47fe-bdd7-bdb168df5022	5c716e9c-b1e4-4da8-8b6c-66e63649ae44	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
14d842de-c94a-4cf5-891c-ced7c3419413	5c716e9c-b1e4-4da8-8b6c-66e63649ae44	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9f46e6ee-12d9-4465-9fdb-1ea9c624a3f7	9297f341-0235-433e-a66c-5ca6bff0411a	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9bd6ce3c-7e6b-4372-81e7-8aff24a797bd	9297f341-0235-433e-a66c-5ca6bff0411a	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
8feba7ab-84f5-41ae-b6a7-587aff4be48b	9297f341-0235-433e-a66c-5ca6bff0411a	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
875f415e-80c2-4668-86e2-d8b3d38c22a2	92b7acff-0598-4d6b-9d9f-5a8ee2cff04e	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9ba27554-207d-445d-bbd5-dc49ce91b3c1	92b7acff-0598-4d6b-9d9f-5a8ee2cff04e	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
cc8de2ef-5b71-4b9e-91b7-718bd3123d77	92b7acff-0598-4d6b-9d9f-5a8ee2cff04e	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
7b45cb3a-6b83-4e19-a2fa-e641b3931898	4bdfea0d-31ba-4f06-80f7-3854d27d6a43	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
0b905c54-eb2a-447e-aa49-37d2ef79957c	4bdfea0d-31ba-4f06-80f7-3854d27d6a43	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5be2deec-97cb-4588-b584-7475898ad3de	4bdfea0d-31ba-4f06-80f7-3854d27d6a43	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
79e01274-c975-4688-8c79-98fbf5630022	2773bc2f-8365-43d6-a173-54dbe1a3713d	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a95b738b-51b0-4fbb-a8ab-27bc7933e01b	2773bc2f-8365-43d6-a173-54dbe1a3713d	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
58bc0c4d-39de-4840-ae3a-3166f53d612b	2773bc2f-8365-43d6-a173-54dbe1a3713d	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
4d922e31-e6e5-4699-a4e9-b3ed1a47adad	a9751085-e9a8-4cb0-97ef-1ed8cb247ce4	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6ec655b8-690f-40da-8152-44556550e3f6	a9751085-e9a8-4cb0-97ef-1ed8cb247ce4	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
c9fef21f-06fa-4c5e-b729-a63f6a08ece2	a9751085-e9a8-4cb0-97ef-1ed8cb247ce4	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d8c41448-97fe-4ffe-84b4-01a8c4ce0738	f5cf157c-e6cd-4e3c-9864-46878fad13ba	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
983ce0c2-7c08-4a38-9d98-fe018d614ccd	f5cf157c-e6cd-4e3c-9864-46878fad13ba	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
119acf31-d8ec-43d3-9a51-8768f8feb223	f5cf157c-e6cd-4e3c-9864-46878fad13ba	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
4948edef-4b56-4aa2-b640-c4137390a69b	30cbe8c9-4c3d-45a8-9a7b-893ba0497e89	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a1038135-46a5-47d1-b188-4e59ab820994	30cbe8c9-4c3d-45a8-9a7b-893ba0497e89	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
ccb97f59-3a0d-4d89-a1c0-98315df7980a	30cbe8c9-4c3d-45a8-9a7b-893ba0497e89	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d357e13b-49d0-4b6d-baab-3717c4113e8e	2099c68d-f84b-474a-b6c0-fedb9b1f2dbe	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
44b06c75-a005-4ba9-8083-e3632c080492	2099c68d-f84b-474a-b6c0-fedb9b1f2dbe	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
4809b55a-f978-4a95-aec2-28579c408800	2099c68d-f84b-474a-b6c0-fedb9b1f2dbe	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d1c268d3-d12a-4af3-8c7a-ac2be2dda586	5207f053-a1a3-4224-9a4a-15aa27ab27ce	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
8ca800b0-c6ca-4ef7-970a-3e91f72d2d46	5207f053-a1a3-4224-9a4a-15aa27ab27ce	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9f3914ba-7ea4-4270-84d2-41e66a8b4383	5207f053-a1a3-4224-9a4a-15aa27ab27ce	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
ed96ddd5-c744-4e44-bd4e-3c624a3f8899	674617f0-5753-4bfd-af59-9e928db0e357	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b6a1e922-c4fa-48ff-9368-fc66ef985656	674617f0-5753-4bfd-af59-9e928db0e357	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
58be5d44-626c-4c6a-87dd-0c000e4f2cdd	674617f0-5753-4bfd-af59-9e928db0e357	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a06d3dc3-a725-4e90-a676-4797e68298bb	4ec48451-e8a7-41d8-9a25-b14fb6712661	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
26925936-9864-4229-8c19-0e2b7d712dee	4ec48451-e8a7-41d8-9a25-b14fb6712661	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
4e0d71e6-5ad6-47c7-a526-95728e01813f	4ec48451-e8a7-41d8-9a25-b14fb6712661	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
df594e5f-169d-43bd-b6ba-0e272ecf56cc	9d1f13c8-6094-4a74-9f29-a7cc65d4daf1	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
2c1362e6-c237-4c65-a1ab-fae037e360ba	9d1f13c8-6094-4a74-9f29-a7cc65d4daf1	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5047a6f6-b21b-4135-ae90-1cccf5760821	9d1f13c8-6094-4a74-9f29-a7cc65d4daf1	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
584a30ef-62a3-4fcb-8161-36320b9e665c	f2dc6958-ad52-4c4f-aa62-11e985a625b8	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
406e6e5b-5757-4d75-bca7-58863d611363	f2dc6958-ad52-4c4f-aa62-11e985a625b8	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
af3e1393-b586-4f0c-8f8f-c012549c9e18	f2dc6958-ad52-4c4f-aa62-11e985a625b8	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
113e08f6-387c-4098-b18c-28dc5c91f9ff	69b57770-bdd8-45d6-aca7-cb686c71c233	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
2c3053de-3f4b-4ba1-945f-d8a1a825c475	69b57770-bdd8-45d6-aca7-cb686c71c233	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
40fcbd40-8ba9-4d62-a2a7-fa4120fb310e	69b57770-bdd8-45d6-aca7-cb686c71c233	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d719f8c3-fd5d-4170-b82a-aa48c39cca38	48f0060b-5248-4868-9d8e-7844ab57d27b	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
16d8d936-5cd2-49e0-a8c5-f3940a578e8a	48f0060b-5248-4868-9d8e-7844ab57d27b	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b6ee3214-0183-4737-a84a-d526cc7ca14d	48f0060b-5248-4868-9d8e-7844ab57d27b	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
8130285d-5f44-43e8-a6eb-bf6422dbf6b2	042e9758-bae0-49e3-a53d-cd98b75d9a39	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
3bd38609-81d3-4fbe-948f-d66519d04ddc	042e9758-bae0-49e3-a53d-cd98b75d9a39	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
c8b5b653-0ea0-451b-9c4d-8c847e48a38d	042e9758-bae0-49e3-a53d-cd98b75d9a39	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5ac429f7-5803-4046-8b6a-da313bf93afb	6c8e4fff-fc9a-4a33-8d68-f4a86b381339	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
763ebcfe-247a-4b9f-a380-7e7fd918b7e9	6c8e4fff-fc9a-4a33-8d68-f4a86b381339	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
777caa79-82ea-48da-894a-7102fe104897	6c8e4fff-fc9a-4a33-8d68-f4a86b381339	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
426cfc3c-2f45-426b-a9a6-fb969f161d86	e7382a51-1499-4d35-9f4d-42731fcf6c49	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
1098b57e-400c-48f1-854c-d8862ed31872	e7382a51-1499-4d35-9f4d-42731fcf6c49	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
780aff33-c8a3-4947-a190-c9b40b34f123	e7382a51-1499-4d35-9f4d-42731fcf6c49	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
21407811-3aa9-44e5-a907-bce7ef845ffb	439eb8e6-59d0-4f2f-b210-f4da6ad5efa2	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
8744728e-42e1-4e29-a159-a1c119483f43	439eb8e6-59d0-4f2f-b210-f4da6ad5efa2	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a9b73941-90c2-4352-921b-1d900e05055b	439eb8e6-59d0-4f2f-b210-f4da6ad5efa2	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d88c61f6-0e3b-4b0f-9749-5b9cf18b8de8	739bd399-855c-4043-b4b2-e2418079c7bf	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e833fed7-83f0-41b3-bce1-d823b76c143d	739bd399-855c-4043-b4b2-e2418079c7bf	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
788e356b-c6ae-4a7f-a79f-af418c3b1419	739bd399-855c-4043-b4b2-e2418079c7bf	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
13740559-be67-4cd4-b3ff-fa3275d6bdaf	7ff1cfc4-7ff0-4013-b032-369ce8d25f0b	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6c7b9a6e-cfca-4a82-93e4-81740df1ca31	7ff1cfc4-7ff0-4013-b032-369ce8d25f0b	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
3cc9c279-3b02-4ddc-a361-90b94c3375e3	7ff1cfc4-7ff0-4013-b032-369ce8d25f0b	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b79371ec-7b3b-4335-a1e9-92a7930f91a7	caf69fa5-7a26-4c5d-b83d-309ab92d11b0	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
256e27a3-649e-4f14-ba41-fa79d28bfe63	caf69fa5-7a26-4c5d-b83d-309ab92d11b0	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5b08e9d0-0803-464c-b0c5-3c43eaabe927	caf69fa5-7a26-4c5d-b83d-309ab92d11b0	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
37969790-8560-434e-86d0-a7ea7322b1cb	f135bb07-4559-4c15-9c42-39851a743b6c	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
63ba92d8-1ffa-4cc3-9d27-204b5a7b1404	f135bb07-4559-4c15-9c42-39851a743b6c	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a0eb6672-6ea5-4f93-bfce-0d30c40a914b	f135bb07-4559-4c15-9c42-39851a743b6c	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
1ef371ef-5353-4d7e-b7c7-6972728af0b2	f14fe5d9-8dd1-4dd1-ab7b-b8326f65a534	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
693980e1-1040-439b-8dd1-a3d04a8cce57	f14fe5d9-8dd1-4dd1-ab7b-b8326f65a534	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6835be30-737b-441a-a1b1-6122059a6e6a	f14fe5d9-8dd1-4dd1-ab7b-b8326f65a534	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
0b8ff063-9a56-40d8-aa8d-7e5f774723de	dd050ead-d327-48a6-84a8-e37e46a63a51	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6a9fd4e8-f599-4ace-98b7-0f322604121b	dd050ead-d327-48a6-84a8-e37e46a63a51	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f9922563-49c5-4496-b7a1-565642c08336	dd050ead-d327-48a6-84a8-e37e46a63a51	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6c8bd908-572c-4456-a3b5-1249ec94a29e	90efcdd5-0b92-42e7-96d7-bfecbd477eb0	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
29d21da6-a775-413a-9f7a-29546957b343	90efcdd5-0b92-42e7-96d7-bfecbd477eb0	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9f234dab-38c2-4319-a773-c8c547f73310	90efcdd5-0b92-42e7-96d7-bfecbd477eb0	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5a227f20-0ce0-41b6-a8fd-4110728d157e	ef0cd2ed-b9ad-4e37-b2eb-df7282d13521	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
fea5555b-ffc3-4566-9708-21dc71a25b9a	ef0cd2ed-b9ad-4e37-b2eb-df7282d13521	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5adaa070-8941-4e0f-906f-cbe6b794300b	ef0cd2ed-b9ad-4e37-b2eb-df7282d13521	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
dad75f63-78ca-40c2-a235-db22801a992c	5c69f88a-f85a-4b09-a0f8-385e48ad7545	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
89215a90-5cf9-4a78-8cfc-f7099c119272	5c69f88a-f85a-4b09-a0f8-385e48ad7545	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b54ddccc-73ff-47d9-be62-5efc59ee3830	5c69f88a-f85a-4b09-a0f8-385e48ad7545	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
ccefc301-4363-4a10-949a-8f1e4c6ec83a	a7c06b24-9822-4284-9ee1-cf1ca4359826	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
13da3bcc-f0df-4b63-97ad-a28f5ee1de91	a7c06b24-9822-4284-9ee1-cf1ca4359826	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
ecefe559-5a2c-4466-bcbe-1db12d555eae	a7c06b24-9822-4284-9ee1-cf1ca4359826	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
90ede9b0-0e03-4d77-b366-a3a148ed31f5	e6470169-b326-46a5-989a-878256637114	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
2a1c3b7f-5aa1-4efe-aba8-86c871ca4541	e6470169-b326-46a5-989a-878256637114	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e9381677-ffc3-4ef5-b345-c369de06325b	e6470169-b326-46a5-989a-878256637114	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
40eb2c8b-2ddd-456a-b9c7-0fc1ecd543e0	28ee21dd-7885-4a15-9981-d04b6aafa1c3	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b2d79d60-2270-4741-8358-645a3d652704	28ee21dd-7885-4a15-9981-d04b6aafa1c3	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9e8ce472-fcc6-4a37-832d-aac1dfdc5dd7	28ee21dd-7885-4a15-9981-d04b6aafa1c3	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f387efc4-855a-4582-82e6-88d6ed063071	e46f7fac-97c5-4aa6-abd3-1757993bde9b	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
3187ee19-66b1-4bcc-9aac-45109c3a815d	e46f7fac-97c5-4aa6-abd3-1757993bde9b	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d867e667-c2c1-4ea7-b618-5b3f25c9b947	e46f7fac-97c5-4aa6-abd3-1757993bde9b	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
75384fbf-9d4f-4d7e-8858-c4b20ad59448	3effd2a9-babf-4354-bb8c-11eaaff840d1	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6186acae-bcfe-47f9-a09b-98f80194b08a	3effd2a9-babf-4354-bb8c-11eaaff840d1	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
49a52470-727d-408b-b967-8195567c253a	3effd2a9-babf-4354-bb8c-11eaaff840d1	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6470cde9-c84b-440b-9f3d-4330b6a2de52	7d5384a9-b88b-4987-84cc-f821434dca1e	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a65cfe97-06af-4cbc-a528-bd4afe8d5cb2	7d5384a9-b88b-4987-84cc-f821434dca1e	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6d9f0f94-a58f-4a6f-ba32-6ae307f5ccc9	7d5384a9-b88b-4987-84cc-f821434dca1e	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
8f4e5566-aef7-49d3-8a5d-452ea6122d7b	21ac53ee-2851-4be1-83f5-d81ff829621a	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
18640f72-1a8d-4581-8d2c-cfbd1fe86062	21ac53ee-2851-4be1-83f5-d81ff829621a	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5cf53d56-f83e-4cad-ae0e-6dba1fa2b9f2	21ac53ee-2851-4be1-83f5-d81ff829621a	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e51520eb-5cf6-45be-8479-752db219db7f	19cb15cb-cd51-4223-8d70-ba18545777d3	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b0c0816a-d12a-477b-9fd9-3c58158dd04d	19cb15cb-cd51-4223-8d70-ba18545777d3	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
c36eb45c-ea42-4da6-9758-4f91a241259d	19cb15cb-cd51-4223-8d70-ba18545777d3	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d1ac0cb2-a517-4c95-9b62-0cc0e207407c	cc10e0a1-89cb-42b1-bf8c-c396346c2e9a	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
4cd3894d-4b13-46d6-a30e-762f8e05ce75	cc10e0a1-89cb-42b1-bf8c-c396346c2e9a	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5332df48-ff95-432e-8e12-66c2615e3c1a	cc10e0a1-89cb-42b1-bf8c-c396346c2e9a	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
7758552f-de4a-4319-ba91-bb92f52d4183	f764f07f-ac16-4458-bddf-961c3a068bba	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
0409f7a7-e26d-4c6e-9836-de1b1786612f	f764f07f-ac16-4458-bddf-961c3a068bba	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f908a54d-a6ab-4982-a902-6003444bd9ee	f764f07f-ac16-4458-bddf-961c3a068bba	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
1ac0b1fa-1822-4069-ab4d-915f3f777077	3e334047-c1e3-49ee-8a80-351bd12b15eb	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e8331eb9-cb57-4ee0-80a9-ea982bf7d39c	3e334047-c1e3-49ee-8a80-351bd12b15eb	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
71ebf13c-421b-4865-a132-5a24be69630f	3e334047-c1e3-49ee-8a80-351bd12b15eb	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
3df2495d-4ea4-4aac-a430-030b554c6061	f166e388-c817-4dfb-90b1-91ce3f409af5	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
014c45fe-0d4c-4ee7-90c8-4e48bf3da0e5	f166e388-c817-4dfb-90b1-91ce3f409af5	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b0fb685b-80e5-4ba3-9276-cb8e6af5bf38	f166e388-c817-4dfb-90b1-91ce3f409af5	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5c2b2e33-dac8-45da-b1ca-9a1ff768a916	84794059-1303-4c66-84e5-638b287ddc74	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
06f3f6bc-b0ba-4148-a94b-970004a2c99b	84794059-1303-4c66-84e5-638b287ddc74	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
7027b0b2-5c35-44c1-8944-5e26b1047e28	84794059-1303-4c66-84e5-638b287ddc74	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
53c63891-eb49-4180-8ff2-a30b70af824d	1d9b1a3b-dabe-43cb-ba5a-7878d7d9c1ba	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
25358976-213f-4bcb-99d2-84430018369f	1d9b1a3b-dabe-43cb-ba5a-7878d7d9c1ba	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
eadd3dc4-01e0-4790-b7e1-857de5eeffa0	1d9b1a3b-dabe-43cb-ba5a-7878d7d9c1ba	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
93d79021-7f92-4d8f-8328-b851291456d1	a62219d6-10a8-4676-a048-6aa258c7b50c	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
488044e0-de33-488f-9fdf-399aa6a5cf30	a62219d6-10a8-4676-a048-6aa258c7b50c	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
7cb04952-9d8f-4b19-be4a-3d725150730d	a62219d6-10a8-4676-a048-6aa258c7b50c	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
cf2b10bd-b8cf-436e-bbe9-3c482b099d90	aa937fb5-9a49-4e67-8bb5-e0f7a594c41d	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
54d5e90d-db94-43e9-826a-6a882bdc5887	aa937fb5-9a49-4e67-8bb5-e0f7a594c41d	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
26783941-cd75-466b-8714-625e0a0ca4c3	aa937fb5-9a49-4e67-8bb5-e0f7a594c41d	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b63bdc00-d1b0-45ef-8e42-9afbe41e34ae	8b1a0f39-934e-4a17-9b3d-15fd50f3cb94	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
ed80ae0a-01cb-4db6-a704-dcde11a5a3f7	8b1a0f39-934e-4a17-9b3d-15fd50f3cb94	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
81781b31-b37b-4a63-891b-0d50877469ca	8b1a0f39-934e-4a17-9b3d-15fd50f3cb94	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
7e56d988-8bef-450e-8aa2-17cbfe1a8061	4a403d53-61c3-49ea-a881-705cbe397dcf	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d227c058-9328-431e-ad35-11530ef8a0d3	4a403d53-61c3-49ea-a881-705cbe397dcf	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
98c2b9de-ceb4-4624-8e4d-166a0da6b99e	4a403d53-61c3-49ea-a881-705cbe397dcf	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
ef83710f-937a-4114-9b4a-8c328a4e81a2	6af419cf-6199-4584-9b43-aa78faad995b	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
47b2afb8-fe42-4859-adc4-af743948ac1f	6af419cf-6199-4584-9b43-aa78faad995b	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
ad0eb582-dc76-42a1-8ec0-34211bb0df17	6af419cf-6199-4584-9b43-aa78faad995b	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b75f3c3f-5c49-4877-9f19-594eca135bc0	7606a6f5-17c5-4b67-945a-4772fd826a01	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a6194708-b44c-4f0c-95e7-d357d61f6829	7606a6f5-17c5-4b67-945a-4772fd826a01	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9c833f0d-16f8-4f15-8a80-bc033f3bdde1	7606a6f5-17c5-4b67-945a-4772fd826a01	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
8bc9f478-00ce-426e-ba6c-5c343fb8472f	62a9266b-1027-4502-b1ae-8b902dfe7fec	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
3582d0e9-996b-4d92-9dc0-8aea6e335e93	62a9266b-1027-4502-b1ae-8b902dfe7fec	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b05d9e4a-a5a9-48ba-a62d-c5007c9a0c56	62a9266b-1027-4502-b1ae-8b902dfe7fec	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
2cf05630-b42b-459f-abb1-d837b471cb55	89e6e076-438c-4c5b-87ce-b559ae9cc66c	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
70dd8dba-8f59-4490-b69c-ccdbc0ce9d85	89e6e076-438c-4c5b-87ce-b559ae9cc66c	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a616e967-4020-4050-a26c-89dd83443c28	89e6e076-438c-4c5b-87ce-b559ae9cc66c	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5a5e1821-75db-4ab5-9a00-2de950ae13ae	b3693735-c3f7-46c2-8a6b-58ae13e4d797	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
da1117a7-6009-4106-8669-44abbffade2a	b3693735-c3f7-46c2-8a6b-58ae13e4d797	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
fdc94a68-681b-48dc-a1f0-320d5963525b	b3693735-c3f7-46c2-8a6b-58ae13e4d797	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
886a9153-44b0-4d92-bfd3-bf089a2d8ec4	4e73daad-756b-43c2-a4a1-ca0839f28945	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
491cd269-4631-4ae0-a1ab-63f9fd517d68	4e73daad-756b-43c2-a4a1-ca0839f28945	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d7977871-81b1-4265-a715-5ddba4ecd854	4e73daad-756b-43c2-a4a1-ca0839f28945	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
58feaeca-f167-4ab0-9e27-e155cee3905c	1577cf1a-f56c-4fb5-879e-4b93255ff77f	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
2e146916-872a-448c-a2e1-3fc04c4b3836	1577cf1a-f56c-4fb5-879e-4b93255ff77f	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
04bf68d5-f574-438e-b07a-6db685d61017	1577cf1a-f56c-4fb5-879e-4b93255ff77f	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
af88a1fa-5b44-4e65-b36d-dde678592470	2bc7aba6-8cc1-445f-ab48-3615c179202e	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
3e92a74e-6766-4a34-b0c6-a4e96ecd7e22	2bc7aba6-8cc1-445f-ab48-3615c179202e	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d2b3a833-dbf1-452e-9a3b-4c33db740e52	2bc7aba6-8cc1-445f-ab48-3615c179202e	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a0e290d5-6dae-4af4-836f-b83ee5894cf3	9ab5f35a-7009-4e35-b3b9-004b08058bf3	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
fa3d8275-c975-4d4a-a7d8-7ab8ff334631	9ab5f35a-7009-4e35-b3b9-004b08058bf3	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
971958e3-4e03-458d-b77f-3700ecbb1599	9ab5f35a-7009-4e35-b3b9-004b08058bf3	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a8a8dcd3-ffdf-4e67-9adc-137bf28fc31b	64331c5f-ca06-47ef-a51d-7f0881d02679	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
7c6d2416-6757-4c19-bac0-1a6ae6c600e7	64331c5f-ca06-47ef-a51d-7f0881d02679	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
16feff15-dd97-409f-b25a-72d676dd83cf	64331c5f-ca06-47ef-a51d-7f0881d02679	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
630d6474-73a0-4240-aacf-8d49e7d9088c	1f413de0-b217-4e4d-b996-34e16990a51d	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
267831ae-a1b5-42fb-bd3d-d90cf38b8df4	1f413de0-b217-4e4d-b996-34e16990a51d	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
14c64b8c-e6c5-4e67-9e8d-28c290cd3bcf	1f413de0-b217-4e4d-b996-34e16990a51d	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a0382553-779c-416d-8be2-8fdf9b1a118e	95471473-5cd7-4496-82ed-8f54eb35ea0d	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6209bd5f-fbf8-4367-b5c6-5e2af084912c	95471473-5cd7-4496-82ed-8f54eb35ea0d	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
330a1232-a970-45bf-b97c-2df64d647f44	95471473-5cd7-4496-82ed-8f54eb35ea0d	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e96359d6-3c46-4e84-87aa-2ee94bbb5c4c	90b07974-e6ef-429d-8416-0cf7be5bafd4	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
950d36f3-0e71-4c6b-8c3c-b116fbf79427	90b07974-e6ef-429d-8416-0cf7be5bafd4	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
b7318312-13e0-458d-894f-1bf43563d72a	90b07974-e6ef-429d-8416-0cf7be5bafd4	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f654fbad-bfd8-4e33-adb8-3d29ba22e48d	5fbf9d7a-4646-45de-8afe-b0396ba7b5a4	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e9a3374c-c36b-4b5b-840f-026daf4d09be	5fbf9d7a-4646-45de-8afe-b0396ba7b5a4	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
3968c7b2-7d40-4043-8e4c-4768a69f174d	5fbf9d7a-4646-45de-8afe-b0396ba7b5a4	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
fb2ecd15-80fc-47b8-9b4e-7a2234f7c12b	3376a68c-fde7-42c1-ab4d-435fab9c41e9	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9fec3f68-da21-4f91-9d96-a44beb7d53ae	3376a68c-fde7-42c1-ab4d-435fab9c41e9	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
51dc8820-13ea-4339-8c3b-c2cdbf5cd9fb	3376a68c-fde7-42c1-ab4d-435fab9c41e9	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f6f9770f-fba3-4ffd-a4d8-155579b5623c	129ba608-00c1-4472-87f5-9b780f7bb042	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6ffedd03-8fa8-4029-9556-123c38c7eba2	129ba608-00c1-4472-87f5-9b780f7bb042	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
8fdbbda5-69ad-49c3-be56-6525e5f78d59	129ba608-00c1-4472-87f5-9b780f7bb042	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
4b08aafa-2856-4cd3-9051-4346f590adcc	26999db5-99e7-4da3-ac85-758ec7078e0d	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
82833b50-64b1-46d1-b095-b5d97d1b4345	26999db5-99e7-4da3-ac85-758ec7078e0d	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
58fefb37-bae3-432d-a48c-53aad3df8c11	26999db5-99e7-4da3-ac85-758ec7078e0d	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
1ea3ba13-8037-4095-b410-1f70ff70fe9e	f003a689-aff9-4fbc-940f-694a7fe56f29	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
9a9698ac-b6fe-40a0-b42e-c464b8d81cfe	f003a689-aff9-4fbc-940f-694a7fe56f29	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e21e3981-9524-48d5-96ed-951bd13326a2	f003a689-aff9-4fbc-940f-694a7fe56f29	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
ff84b428-e906-4046-81e6-1d55f63f5581	cf27ae3d-ee82-44f0-80ba-eb5931dd6f55	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
6df13d4b-0e61-4376-8fce-ba194e009c1d	cf27ae3d-ee82-44f0-80ba-eb5931dd6f55	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
06ef578c-d27d-44c6-a73a-0c853bb48227	cf27ae3d-ee82-44f0-80ba-eb5931dd6f55	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
305138c8-8b88-4881-9d2c-4fae80432b6d	fe88150a-e1eb-4742-95a9-d7e2ce5b62c0	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
aa601552-e1dc-4f2b-ab75-e0a7d8267248	fe88150a-e1eb-4742-95a9-d7e2ce5b62c0	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
c66dfb11-10a7-44ed-bc11-5654fb904de1	fe88150a-e1eb-4742-95a9-d7e2ce5b62c0	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
3cfabf8b-f114-4c86-a416-9c5249331faa	d5c384f2-4dff-4508-ba02-f81c5e7eaf02	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
7a6a4e75-0866-4c17-bbe3-4f1f8a4c7a6b	d5c384f2-4dff-4508-ba02-f81c5e7eaf02	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
775d0bb2-f584-48f7-9450-f915403dedff	d5c384f2-4dff-4508-ba02-f81c5e7eaf02	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d38c4ea6-7409-46c6-8d25-67d8225d7fd7	505e2654-511a-4fad-852c-10c1a20577b9	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
ff85197c-7157-4796-a5bd-244167163888	505e2654-511a-4fad-852c-10c1a20577b9	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
273a2ae0-6d2e-4f09-b947-70af8ded7f9a	505e2654-511a-4fad-852c-10c1a20577b9	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
774962d7-c8d5-46a8-af68-70c644d0556d	f482e70c-94ec-4a48-9699-a47315a5ec3a	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5574cd19-a5cf-4e55-bab8-0a8b3dba76cd	f482e70c-94ec-4a48-9699-a47315a5ec3a	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
2c8a9ed0-e078-4bc4-bebc-bf15c57c0f42	f482e70c-94ec-4a48-9699-a47315a5ec3a	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
15f444a2-85d8-4178-8786-a892e2ca2031	bff8f563-6312-4c35-bd6c-bf150a598567	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
4ffc2f51-6fad-42a1-a3a8-e65bda781aa6	bff8f563-6312-4c35-bd6c-bf150a598567	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
72d348d0-8f9b-4894-bc7a-63062eb92f19	bff8f563-6312-4c35-bd6c-bf150a598567	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
0713ee85-8408-4c0e-b473-f2b6ae457a71	e6731988-19f7-4a6d-a583-562978836228	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
dee937f9-f091-4a2c-899f-9adedc36248a	e6731988-19f7-4a6d-a583-562978836228	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
52fcd864-f133-4838-9f80-9467fe3da037	e6731988-19f7-4a6d-a583-562978836228	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
e485cfdb-f053-4859-84b3-3aa7c2e532ef	1b52a101-47f5-4eca-b6f1-d9c856a9377d	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
477b1802-f202-4b5f-9507-b7e231d8c6d8	1b52a101-47f5-4eca-b6f1-d9c856a9377d	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
d5a7cb74-f651-4e79-9616-522a2236dd56	1b52a101-47f5-4eca-b6f1-d9c856a9377d	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
2b9f6605-ccb2-4d70-bf04-2f70e2d2534b	3d4a383e-07c2-416d-b39b-a8714fe003e1	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
f06192c8-2aab-4c44-8960-a2e1fdcefe17	3d4a383e-07c2-416d-b39b-a8714fe003e1	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
5e7ab385-3367-4704-9d99-59b262ad3c75	3d4a383e-07c2-416d-b39b-a8714fe003e1	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
46ea47d1-bf76-492e-8141-f471977336d1	71abdf5c-4796-471c-a105-a8776a08246d	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a99ff18a-8814-4dfc-b319-698bd39dc7cd	71abdf5c-4796-471c-a105-a8776a08246d	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
97ed040a-5605-4a4e-9337-586f9c12d6b4	71abdf5c-4796-471c-a105-a8776a08246d	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
a8999cc6-e7ae-4edb-adfe-d102b1105868	83139a8d-9c50-409e-a661-e93a3066ac91	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
918f1a5d-c39d-4904-abaa-b4accd0e176b	83139a8d-9c50-409e-a661-e93a3066ac91	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
cd3d76bc-95b9-420a-82b8-a3026366e61a	83139a8d-9c50-409e-a661-e93a3066ac91	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
55a1a568-bf83-45a6-8d7a-9b0e63d20926	eb36c257-5eb3-4860-916a-608ab90a4a6a	bio	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
05e058d0-c89a-4b1c-93d2-aa53ce8f4744	eb36c257-5eb3-4860-916a-608ab90a4a6a	quim	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
fa2b89d9-5b1d-4075-bafe-1e77e1355778	eb36c257-5eb3-4860-916a-608ab90a4a6a	fis	0	0	f	0.00	\N	2026-05-22 21:25:43.933275+00	2026-05-22 21:25:43.933275+00
176593ac-b00e-4bba-933e-684945d37d28	00000000-0000-0000-0000-000000000099	bio	2	0	f	5.00	2026-05-23 19:18:56.376+00	2026-05-23 19:00:59.36899+00	2026-05-23 19:18:56.562648+00
e34e76d3-bc89-424d-98c5-f98825738aca	00000000-0000-0000-0000-000000000099	quim	3	0	f	7.00	2026-05-23 19:57:38.163+00	2026-05-23 19:00:59.36899+00	2026-05-23 19:57:38.346273+00
05c6da3a-7bb7-46c7-b3a6-b21a1e712066	00000000-0000-0000-0000-000000000099	fis	2	0	f	5.00	2026-05-23 20:45:27.84+00	2026-05-23 19:00:59.36899+00	2026-05-23 20:45:28.012084+00
\.


--
-- Data for Name: questoes_banco; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.questoes_banco (id, origem, gerada_para, disciplina, tema, subtema, tipo, nivel, interdisciplinar_com, enunciado, texto_base, alternativas, gabarito, explicacao, steps, elementos_visuais, status, revisada_por, revisada_em, nota_revisor, vezes_usada, total_respostas, total_acertos, taxa_acerto, created_at, updated_at) FROM stdin;
6233004e-684c-4426-8ca8-89583701b710	ia_gerada	00000000-0000-0000-0000-000000000099	inter	Equilíbrio Químico	pH, Ka e Lei de Diluição de Ostwald	A	intermediario	{quim,bio}	Considere que, durante a calibração do biossensor, uma amostra de suor contendo ácido lático seja diluída pela adição de água destilada. Essa diluição promove a diminuição da concentração de íons \\(\\mathrm{H_3O^+}\\), resultando no aumento do pH medido; simultaneamente, de acordo com a Lei de Diluição de Ostwald, ocorre uma diminuição no grau de ionização (\\(\\alpha\\)) do ácido lático para manter a constante de acidez (\\(K_a\\)) inalterada.	{"paragrafos": ["Biossensores eletroquímicos vestíveis (wearables) representam uma tecnologia inovadora para o monitoramento em tempo real da saúde e do rendimento físico de atletas. Esses dispositivos analisam o suor continuamente para mensurar a concentração de ácido lático (ácido 2-hidroxipropanoico, \\\\(\\\\mathrm{C_3H_6O_3}\\\\)), um subproduto do metabolismo anaeróbico lático que se acumula nos músculos e na corrente sanguínea durante exercícios de alta intensidade.", "O funcionamento do sensor baseia-se na detecção potenciométrica da variação de pH do suor, a qual está diretamente relacionada à ionização do ácido lático em meio aquoso, conforme o equilíbrio químico representado a seguir:"], "elementos_visuais": []}	\N	ERRADO	A afirmativa está incorreta devido a uma pegadinha conceitual clássica sobre a Lei de Diluição de Ostwald. De fato, a diluição (adição de água) diminui a concentração total de íons \\(\\mathrm{H_3O^+}\\) por unidade de volume, o que eleva o pH da solução (torna-a menos ácida). Contudo, a diluição desloca o equilíbrio no sentido de maior número de partículas (sentido direto da ionização), o que significa que o grau de ionização (\\(\\alpha\\)) do ácido fraco aumenta, e não diminui. Matematicamente, para ácidos fracos com baixo grau de ionização, a relação é dada por: \\[ K_a \\approx C_{\\mathrm{M}} \\cdot \\alpha^2 \\] Onde \\(C_{\\mathrm{M}}\\) é a concentração em quantidade de matéria. Como a temperatura permanece constante, \\(K_a\\) não se altera. Assim, se a concentração \\(C_{\\mathrm{M}}\\) diminui devido à diluição, o grau de ionização \\(\\alpha\\) obrigatoriamente deve aumentar para manter a igualdade.	\N	[{"tipo": "equacao_quimica", "titulo": "Equilíbrio de Ionização do Ácido Lático", "equacao": "\\\\mathrm{C_3H_6O_{3(aq)} + H_2O_{(l)} \\\\rightleftharpoons H_3O^+_{(aq)} + C_3H_5O^-_{3(aq)}} \\\\quad K_a = 1{,}4 \\\\cdot 10^{-4}"}]	pendente	\N	\N	\N	0	0	0	\N	2026-05-23 19:57:16.001518+00	2026-05-23 20:39:53.773586+00
493d9ba9-46be-4a9e-b02b-aff52ba08cf6	ia_gerada	00000000-0000-0000-0000-000000000099	inter	Equilíbrio Químico	Princípio de Le Chatelier e Efeito Joule	A	avancado	{quim,fis}	Considerando o funcionamento do microrreator descrito, se a corrente elétrica \\(I\\) que atravessa o resistor de aquecimento for duplicada, a potência térmica dissipada por efeito Joule será quadruplicada, elevando a temperatura do sistema. Esse aumento de temperatura deslocará o equilíbrio químico no sentido endotérmico (reagentes), reduzindo o valor da constante de equilíbrio \\(K_c\\); contudo, a presença do catalisador de platina reverterá esse deslocamento termodinâmico, restabelecendo o rendimento original de \\(\\mathrm{N_2O_{4(g)}}\\) sob a nova temperatura de operação.	{"paragrafos": ["Em microrreatores analíticos utilizados em biossensores gasosos de alto desempenho, o controle térmico preciso é fundamental para garantir a seletividade e a reprodutibilidade das análises. Um desses dispositivos monitora a dimerização do dióxido de nitrogênio (gás castanho) em tetróxido de dinitrogênio (gás incolor), uma reação reversível e exotérmica utilizada para calibração de sensores ambientais, representada pela equação química:", "\\\\[ 2\\\\,\\\\mathrm{NO_{2(g)}} \\\\rightleftharpoons \\\\mathrm{N_2O_{4(g)}} \\\\quad \\\\Delta H = -57{,}2\\\\text{ kJ/mol} \\\\]", "O controle de temperatura do microrreator é realizado por meio de uma microresitência de platina integrada. Ao aplicar uma corrente elétrica \\\\(I\\\\) sobre o resistor de resistência \\\\(R\\\\), o calor gerado por efeito Joule mantém a câmara de reação em uma temperatura controlada. Para acelerar o tempo de resposta do sensor, as paredes internas do microrreator são revestidas com uma camada ultrafina de platina dispersa, que atua como catalisador heterogêneo."], "elementos_visuais": []}	\N	ERRADO	A afirmativa contém uma pegadinha conceitual sutil sobre o papel dos catalisadores no equilíbrio químico. Analisando os passos:\n\n1. **Física (Efeito Joule)**: A potência dissipada por um resistor é dada por \\(P = R \\cdot I^2\\). Se a corrente elétrica \\(I\\) é duplicada, a potência térmica gerada aumenta por um fator de \\(2^2 = 4\\) (quadruplica), o que de fato eleva a temperatura do microrreator.\n\n2. **Química (Le Chatelier)**: Como a reação de dimerização do \\(\\mathrm{NO_2}\\) é exotérmica (\\(\\Delta H < 0\\)), o aumento de temperatura favorece o sentido endotérmico (reagentes), deslocando o equilíbrio para a esquerda e diminuindo o valor da constante de equilíbrio \\(K_c\\).\n\n3. **Química (Catalisador - Erro Conceitual)**: O catalisador atua exclusivamente na cinética química, diminuindo a energia de ativação (\\(E_a\\)) de ambos os sentidos da reação (direto e inverso) na mesma proporção. Ele acelera a velocidade com que o equilíbrio é atingido, mas **não altera a termodinâmica do sistema**, não modifica a constante \\(K_c\\) e não altera a composição de equilíbrio. Portanto, o catalisador jamais reverterá o deslocamento termodinâmico provocado pela temperatura ou restabelecerá o rendimento original.	\N	[{"tipo": "grafico_energia", "titulo": "Perfil Energético da Reação de Dimerização do NO2", "produtos": -57, "reagentes": 0, "com_catalisador": 40, "estado_transicao": 80}, {"tipo": "grafico_energia", "titulo": "Perfil Energético da Reação de Dimerização do NO2"}]	pendente	\N	\N	\N	0	0	0	\N	2026-05-23 19:58:14.896107+00	2026-05-23 20:39:53.773586+00
055caaec-3604-439c-8e54-d3a59ff80d60	ia_gerada	00000000-0000-0000-0000-000000000099	inter	Eletrodinâmica e Eletroquímica	Potência Elétrica e Pilhas de Lítio	C	avancado	{fis,quim}	Com base nos conceitos de eletrodinâmica e eletroquímica, determine, respectivamente, a potência elétrica média consumida pelo circuito do marcapasso e o tempo estimado de vida útil dessa bateria, em anos, considerando que ela opere continuamente até sua descarga total.	{"paragrafos": ["Os marcapassos cardíacos artificiais são dispositivos eletrônicos implantáveis que auxiliam no controle do ritmo cardíaco de pacientes com bradicardia. Para garantir a segurança e evitar cirurgias frequentes de substituição, esses dispositivos utilizam baterias de lítio-iodo (\\\\(\\\\text{Li/I}_2\\\\)), conhecidas por sua altíssima confiabilidade, baixa taxa de autodescarga e densidade energética elevada.", "Nessa célula eletroquímica, o lítio metálico sofre oxidação no ânodo, enquanto o iodo molecular é reduzido no cátodo, gerando uma diferença de potencial (ddp) constante de \\\\(2{,}80\\\\text{ V}\\\\). O eletrólito sólido de iodeto de lítio (\\\\(\\\\text{LiI}\\\\)) atua como separador e condutor iônico.", "Considere um marcapasso moderno cujo circuito eletrônico opera sob uma corrente média contínua de \\\\(15{,}0\\\\text{ }\\\\mu\\\\text{A}\\\\) fornecida por uma bateria de \\\\(\\\\text{Li/I}_2\\\\) com capacidade nominal de carga de \\\\(1{,}314\\\\text{ Ah}\\\\)."], "elementos_visuais": []}	{"A": "\\\\(42{,}0\\\\text{ }\\\\mu\\\\text{W}\\\\) e \\\\(10{,}0\\\\text{ anos}\\\\)", "B": "\\\\(42{,}0\\\\text{ }\\\\mu\\\\text{W}\\\\) e \\\\(5{,}0\\\\text{ anos}\\\\)", "C": "\\\\(11{,}4\\\\text{ }\\\\mu\\\\text{W}\\\\) e \\\\(10{,}0\\\\text{ anos}\\\\)", "D": "\\\\(84{,}0\\\\text{ }\\\\mu\\\\text{W}\\\\) e \\\\(8{,}5\\\\text{ anos}\\\\)", "E": "\\\\(15{,}0\\\\text{ }\\\\mu\\\\text{W}\\\\) e \\\\(12{,}0\\\\text{ anos}\\\\)"}	A	A potência elétrica média consumida é dada pelo produto da tensão pela corrente elétrica: \\(P = V \\cdot I = 2{,}80\\text{ V} \\cdot 15{,}0 \\cdot 10^{-6}\\text{ A} = 42{,}0\\text{ }\\mu\\text{W}\\). O tempo de vida útil da bateria é calculado pela relação entre a capacidade de carga e a corrente consumida: \\(t = \\frac{Q}{I} = \\frac{1{,}314\\text{ Ah}}{15{,}0 \\cdot 10^{-6}\\text{ A}} = 87\\,600\\text{ h}\\). Dividindo esse valor pelo total de horas em um ano (\\(8760\\text{ h}\\)), obtemos exatamente \\(10{,}0\\text{ anos}\\).	[{"hint": "Utilize a relação fundamental da potência elétrica em corrente contínua.", "titulo": "Cálculo da Potência Elétrica Média", "explicacao": "A potência elétrica dissipada ou consumida por um circuito é o produto da diferença de potencial aplicada pela corrente elétrica que o atravessa.", "linhas_latex": ["P = V \\\\cdot I", "P = 2{,}80 \\\\text{ V} \\\\cdot 15{,}0 \\\\cdot 10^{-6} \\\\text{ A}", "P = 42{,}0 \\\\cdot 10^{-6} \\\\text{ W}"], "destaque_latex": "P = 42{,}0 \\\\text{ } \\\\mu\\\\text{W}"}, {"hint": "Relacione a capacidade de carga com a corrente elétrica.", "titulo": "Cálculo do Tempo de Vida Útil em Horas", "explicacao": "A capacidade de carga \\\\(Q\\\\) é dada pelo produto da corrente pelo tempo. Assim, o tempo de funcionamento é a razão entre a carga total e a corrente média.", "linhas_latex": ["t = \\\\frac{Q}{I}", "t = \\\\frac{1{,}314 \\\\text{ Ah}}{15{,}0 \\\\cdot 10^{-6} \\\\text{ A}}", "t = \\\\frac{1{,}314 \\\\text{ A} \\\\cdot \\\\text{h}}{1{,}50 \\\\cdot 10^{-5} \\\\text{ A}}", "t = 87\\\\,600 \\\\text{ h}"], "destaque_latex": "t = 87\\\\,600 \\\\text{ h}"}, {"hint": "Divida o total de horas pelo número de horas em um ano.", "titulo": "Conversão do Tempo para Anos", "explicacao": "Considerando que um ano possui \\\\(365\\\\text{ dias}\\\\) de \\\\(24\\\\text{ horas}\\\\), o total de horas anuais é \\\\(8760\\\\text{ h}\\\\). Dividimos o tempo total por esse fator.", "linhas_latex": ["t_{\\\\text{anos}} = \\\\frac{t}{8760 \\\\text{ h/ano}}", "t_{\\\\text{anos}} = \\\\frac{87\\\\,600 \\\\text{ h}}{8760 \\\\text{ h/ano}}"], "destaque_latex": "t_{\\\\text{anos}} = 10{,}0 \\\\text{ anos}"}]	[{"tipo": "tabela", "linhas": [["Tensão nominal (V)", "2,80 V"], ["Capacidade de carga (Q)", "1,314 Ah"], ["Corrente média de operação (I)", "15,0 µA"], ["Relação de tempo anual", "1 ano = 365 dias (8760 h)"]], "titulo": "Especificações Técnicas da Bateria de Li/I₂", "cabecalho": ["Parâmetro", "Valor"]}, {"tipo": "tabela", "linhas": [["Tensão nominal (V)", "2,80 V"], ["Capacidade de carga (Q)", "1,314 Ah"], ["Corrente média de operação (I)", "15,0 µA"], ["Relação de tempo anual", "1 ano = 365 dias (8760 h)"]], "titulo": "Especificações Técnicas da Bateria de Li/I₂", "cabecalho": ["Parâmetro", "Valor"]}]	pendente	\N	\N	\N	0	0	0	\N	2026-05-23 20:02:02.812082+00	2026-05-23 20:39:53.773586+00
\.


--
-- Data for Name: respostas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.respostas (id, aluno_id, questao_id, disciplina, tipo, correta, tempo_segundos, streak_momento, pontos_ganhos, created_at) FROM stdin;
2e12d601-5769-4383-bdde-7ee02b895675	00000000-0000-0000-0000-000000000099	fis_c_01	fis	C	f	\N	0	0	2026-05-23 19:02:53.508337+00
55a00d2c-70f7-4e90-b9fd-10093cb0114b	00000000-0000-0000-0000-000000000099	bio_c_01	bio	C	f	\N	0	0	2026-05-23 19:04:35.798213+00
61298488-b77b-4d24-ab0f-fea89baa29a1	00000000-0000-0000-0000-000000000099	quim_c_01	quim	C	f	\N	0	0	2026-05-23 19:16:39.666672+00
4311ae4e-3116-41ef-941a-056cb934824c	00000000-0000-0000-0000-000000000099	quim_c_02	quim	C	f	\N	0	0	2026-05-23 19:16:53.474839+00
f2782aca-c052-49fb-b39b-24db31660139	00000000-0000-0000-0000-000000000099	bio_c_02	bio	C	f	\N	0	0	2026-05-23 19:18:56.252249+00
4faeb35e-740f-42fd-bea2-e9ca1d18d60c	00000000-0000-0000-0000-000000000099	ia_1779566236218	quim	A	f	\N	0	0	2026-05-23 19:57:38.056402+00
da37c530-5e01-4109-9e83-d4ed5fe41cd9	00000000-0000-0000-0000-000000000099	banco_055caaec-3604-439c-8e54-d3a59ff80d60	fis	C	f	\N	0	0	2026-05-23 20:45:27.517003+00
\.


--
-- Data for Name: sessoes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessoes (id, aluno_id, pagina, inicio, fim, duracao_segundos, created_at) FROM stdin;
60e0e028-cef9-42f2-9736-57a365ad72f6	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:02:30.789425+00	2026-05-23 19:02:39.935567+00	9	2026-05-23 19:02:30.789425+00
81cb723f-0765-499f-90dd-c7613a1dc0cd	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:04:17.334376+00	\N	\N	2026-05-23 19:04:17.334376+00
a44706d7-9f26-42ae-a20c-f2ca068321ec	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:05:28.983865+00	\N	\N	2026-05-23 19:05:28.983865+00
c44cebed-a9ab-4c46-a6c8-0474d607ad51	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:18:39.835639+00	\N	\N	2026-05-23 19:18:39.835639+00
182e2f98-505d-4750-a0cf-ddb6973ff8d5	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:22:50.982361+00	\N	\N	2026-05-23 19:22:50.982361+00
8f48f52e-5685-4438-a243-37dfac80b605	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:24:46.932437+00	\N	\N	2026-05-23 19:24:46.932437+00
dda527fc-7648-469f-a717-2d662a548334	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:24:51.126689+00	\N	\N	2026-05-23 19:24:51.126689+00
e30ab068-ea22-4dc6-80a9-0e550a05c49f	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:25:34.675724+00	\N	\N	2026-05-23 19:25:34.675724+00
d5c09b5f-c3de-48ba-a153-3b996cdfa9b9	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:25:38.554771+00	\N	\N	2026-05-23 19:25:38.554771+00
f229bf35-378b-4b0c-966b-b5516eec1bb9	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:27:38.599001+00	\N	\N	2026-05-23 19:27:38.599001+00
4081974b-0c46-43e7-ab47-cd7bfe40d438	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:27:42.442739+00	\N	\N	2026-05-23 19:27:42.442739+00
c2a8b40f-98f1-40a8-82f5-0e79f3086e22	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:27:57.541409+00	\N	\N	2026-05-23 19:27:57.541409+00
f2efa546-67dd-46a4-9c7d-06eab9741651	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:30:16.733904+00	\N	\N	2026-05-23 19:30:16.733904+00
967820e4-5d44-4050-91ab-ee6738fcd685	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:30:17.971111+00	\N	\N	2026-05-23 19:30:17.971111+00
eee21ca6-9ff7-4fb1-bd66-07eaf54103e8	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:32:14.99308+00	\N	\N	2026-05-23 19:32:14.99308+00
9645d916-a004-47a8-8ece-6f09dd14d60a	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:33:47.170815+00	\N	\N	2026-05-23 19:33:47.170815+00
e0fba065-e834-4121-acbf-a6ef594b94dc	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:34:15.8795+00	\N	\N	2026-05-23 19:34:15.8795+00
1c9dfd63-4371-4d8d-8d7a-c45df8e2e8c4	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:34:17.401119+00	\N	\N	2026-05-23 19:34:17.401119+00
f9844a89-c56b-44c6-b0dd-adac1574d2ce	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:36:09.349987+00	\N	\N	2026-05-23 19:36:09.349987+00
a319b1e5-81cf-4929-a5c0-27c81da98825	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:36:17.630045+00	\N	\N	2026-05-23 19:36:17.630045+00
3d046bc9-dd7a-4ba5-9516-83c8c1fd43da	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:36:24.251002+00	\N	\N	2026-05-23 19:36:24.251002+00
567bb3f2-df0b-4723-a9da-a7026d8f8520	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:36:27.059449+00	\N	\N	2026-05-23 19:36:27.059449+00
602bf344-74ba-45e1-be5a-1bc74d9bd3aa	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:37:40.271117+00	\N	\N	2026-05-23 19:37:40.271117+00
e7068a12-6045-4e1c-b072-213d4bf20871	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:40:45.846562+00	2026-05-23 19:40:51.163176+00	5	2026-05-23 19:40:45.846562+00
50eab3fe-1cef-457d-b9cc-ac270d807ddf	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:54:57.816439+00	\N	\N	2026-05-23 19:54:57.816439+00
db9552e4-d8d7-466c-8395-5fbecbf467cf	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:55:38.024855+00	2026-05-23 19:55:40.854954+00	3	2026-05-23 19:55:38.024855+00
76cbc102-3687-4938-8e33-d4d935ff5271	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:55:41.409034+00	\N	\N	2026-05-23 19:55:41.409034+00
dbe6f839-d34f-40a0-b315-ffa3bf2d1675	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:56:08.054433+00	\N	\N	2026-05-23 19:56:08.054433+00
b7ca052d-cd26-4ec8-a95f-57b0cc230f27	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:56:12.582708+00	\N	\N	2026-05-23 19:56:12.582708+00
a1d865bf-1848-4fcd-9ed1-4462dcd17627	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:56:13.271933+00	\N	\N	2026-05-23 19:56:13.271933+00
966f2b97-7511-402d-adcf-6d50f30f1b37	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:56:17.221204+00	\N	\N	2026-05-23 19:56:17.221204+00
95be5aa7-4e85-42a7-90d2-36a8baf463ea	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:56:18.791657+00	\N	\N	2026-05-23 19:56:18.791657+00
0c24d0af-7493-4290-922f-54f9d8e1505a	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:56:23.023562+00	\N	\N	2026-05-23 19:56:23.023562+00
3b07872f-d384-4511-898a-644e40db2b6f	00000000-0000-0000-0000-000000000099	portal	2026-05-23 19:56:38.424067+00	2026-05-23 19:56:43.30394+00	5	2026-05-23 19:56:38.424067+00
199c4a31-aae0-40ab-9ca9-8033ef76809b	00000000-0000-0000-0000-000000000099	portal	2026-05-23 20:45:47.44874+00	\N	\N	2026-05-23 20:45:47.44874+00
d66513b6-ef11-4d21-98bd-cc769305b26e	00000000-0000-0000-0000-000000000099	portal	2026-05-23 20:45:52.09009+00	2026-05-23 20:46:02.05118+00	10	2026-05-23 20:45:52.09009+00
df2e8885-66d9-4906-90ff-df4215ddea93	00000000-0000-0000-0000-000000000099	portal	2026-05-23 20:46:49.490584+00	\N	\N	2026-05-23 20:46:49.490584+00
6acf510d-47c1-4db1-8424-6f574893efff	00000000-0000-0000-0000-000000000099	portal	2026-05-23 20:46:56.29198+00	2026-05-23 20:47:00.233718+00	4	2026-05-23 20:46:56.29198+00
\.


--
-- Data for Name: simulado_respostas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.simulado_respostas (id, aluno_id, questao_id, disciplina, tipo, correta, tempo_segundos, pontos_ganhos, created_at) FROM stdin;
\.


--
-- Data for Name: simulado_solicitacoes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.simulado_solicitacoes (id, professor_id, titulo, foco, quantidade_itens, status, observacoes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: simulado_tentativas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.simulado_tentativas (id, aluno_id, iniciado_em, finalizado_em, tempo_total_segundos, pontos_obtidos, concluido, tentativa_num) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-05-22 20:44:23
20211116045059	2026-05-22 20:44:23
20211116050929	2026-05-22 20:44:23
20211116051442	2026-05-22 20:44:23
20211116212300	2026-05-22 20:44:23
20211116213355	2026-05-22 20:44:23
20211116213934	2026-05-22 20:44:23
20211116214523	2026-05-22 20:44:23
20211122062447	2026-05-22 20:44:23
20211124070109	2026-05-22 20:44:23
20211202204204	2026-05-22 20:44:23
20211202204605	2026-05-22 20:44:23
20211210212804	2026-05-22 20:44:23
20211228014915	2026-05-22 20:44:23
20220107221237	2026-05-22 20:44:23
20220228202821	2026-05-22 20:44:23
20220312004840	2026-05-22 20:44:23
20220603231003	2026-05-22 20:44:24
20220603232444	2026-05-22 20:44:24
20220615214548	2026-05-22 20:44:24
20220712093339	2026-05-22 20:44:24
20220908172859	2026-05-22 20:44:24
20220916233421	2026-05-22 20:44:24
20230119133233	2026-05-22 20:44:24
20230128025114	2026-05-22 20:44:24
20230128025212	2026-05-22 20:44:24
20230227211149	2026-05-22 20:44:24
20230228184745	2026-05-22 20:44:24
20230308225145	2026-05-22 20:44:24
20230328144023	2026-05-22 20:44:24
20231018144023	2026-05-22 20:44:24
20231204144023	2026-05-22 20:44:24
20231204144024	2026-05-22 20:44:24
20231204144025	2026-05-22 20:44:24
20240108234812	2026-05-22 20:44:24
20240109165339	2026-05-22 20:44:24
20240227174441	2026-05-22 20:44:24
20240311171622	2026-05-22 20:44:24
20240321100241	2026-05-22 20:44:24
20240401105812	2026-05-22 20:44:24
20240418121054	2026-05-22 20:44:24
20240523004032	2026-05-22 20:44:24
20240618124746	2026-05-22 20:44:24
20240801235015	2026-05-22 20:44:24
20240805133720	2026-05-22 20:44:24
20240827160934	2026-05-22 20:44:24
20240919163303	2026-05-22 20:44:24
20240919163305	2026-05-22 20:44:24
20241019105805	2026-05-22 20:44:24
20241030150047	2026-05-22 20:44:24
20241108114728	2026-05-22 20:44:24
20241121104152	2026-05-22 20:44:24
20241130184212	2026-05-22 20:44:24
20241220035512	2026-05-22 20:44:24
20241220123912	2026-05-22 20:44:24
20241224161212	2026-05-22 20:44:24
20250107150512	2026-05-22 20:44:24
20250110162412	2026-05-22 20:44:24
20250123174212	2026-05-22 20:44:24
20250128220012	2026-05-22 20:44:24
20250506224012	2026-05-22 20:44:24
20250523164012	2026-05-22 20:44:24
20250714121412	2026-05-22 20:44:24
20250905041441	2026-05-22 20:44:24
20251103001201	2026-05-22 20:44:24
20251120212548	2026-05-22 20:44:24
20251120215549	2026-05-22 20:44:24
20260218120000	2026-05-22 20:44:24
20260326120000	2026-05-22 20:44:24
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-05-22 19:53:22.840735
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-05-22 19:53:22.883899
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-05-22 19:53:22.887866
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-05-22 19:53:22.910594
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-05-22 19:53:22.92536
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-05-22 19:53:22.929753
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-05-22 19:53:22.934739
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-05-22 19:53:22.939564
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-05-22 19:53:22.944059
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-05-22 19:53:22.948815
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-05-22 19:53:22.95374
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-05-22 19:53:22.958726
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-05-22 19:53:22.963872
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-05-22 19:53:22.969882
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-05-22 19:53:22.974821
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-05-22 19:53:23.004426
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-05-22 19:53:23.008988
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-05-22 19:53:23.013464
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-05-22 19:53:23.018148
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-05-22 19:53:23.02554
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-05-22 19:53:23.030753
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-05-22 19:53:23.03762
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-05-22 19:53:23.052378
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-05-22 19:53:23.062035
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-05-22 19:53:23.066672
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-05-22 19:53:23.071397
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-05-22 19:53:23.076094
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-05-22 19:53:23.080537
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-05-22 19:53:23.08469
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-05-22 19:53:23.088814
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-05-22 19:53:23.093242
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-05-22 19:53:23.097348
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-05-22 19:53:23.101547
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-05-22 19:53:23.10581
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-05-22 19:53:23.11
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-05-22 19:53:23.114187
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-05-22 19:53:23.118429
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-05-22 19:53:23.122619
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-05-22 19:53:23.127671
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-05-22 19:53:23.140632
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-05-22 19:53:23.145999
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-05-22 19:53:23.150744
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-05-22 19:53:23.154928
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-05-22 19:53:23.159432
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-05-22 19:53:23.163687
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-05-22 19:53:23.169085
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-05-22 19:53:23.181158
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-05-22 19:53:23.186245
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-05-22 19:53:23.191367
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-05-22 19:53:23.208411
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-05-22 19:53:23.214175
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-05-22 19:53:23.377406
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-05-22 19:53:23.37935
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-05-22 19:53:23.389155
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-05-22 19:53:23.392122
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-05-22 19:53:23.394028
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-05-22 19:53:23.399503
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-05-22 19:53:23.405578
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-05-22 19:53:23.410358
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-05-22 19:53:23.41612
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-05-22 19:53:23.420911
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 16, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: badges_conquistados badges_conquistados_aluno_id_badge_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.badges_conquistados
    ADD CONSTRAINT badges_conquistados_aluno_id_badge_id_key UNIQUE (aluno_id, badge_id);


--
-- Name: badges_conquistados badges_conquistados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.badges_conquistados
    ADD CONSTRAINT badges_conquistados_pkey PRIMARY KEY (id);


--
-- Name: notificacoes_professor notificacoes_professor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notificacoes_professor
    ADD CONSTRAINT notificacoes_professor_pkey PRIMARY KEY (id);


--
-- Name: perfis perfis_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perfis
    ADD CONSTRAINT perfis_email_key UNIQUE (email);


--
-- Name: perfis perfis_matricula_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perfis
    ADD CONSTRAINT perfis_matricula_key UNIQUE (matricula);


--
-- Name: perfis perfis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perfis
    ADD CONSTRAINT perfis_pkey PRIMARY KEY (id);


--
-- Name: pontuacao pontuacao_aluno_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pontuacao
    ADD CONSTRAINT pontuacao_aluno_id_key UNIQUE (aluno_id);


--
-- Name: pontuacao pontuacao_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pontuacao
    ADD CONSTRAINT pontuacao_pkey PRIMARY KEY (id);


--
-- Name: progresso_revisao progresso_revisao_aluno_id_disciplina_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.progresso_revisao
    ADD CONSTRAINT progresso_revisao_aluno_id_disciplina_key UNIQUE (aluno_id, disciplina);


--
-- Name: progresso_revisao progresso_revisao_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.progresso_revisao
    ADD CONSTRAINT progresso_revisao_pkey PRIMARY KEY (id);


--
-- Name: questoes_banco questoes_banco_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questoes_banco
    ADD CONSTRAINT questoes_banco_pkey PRIMARY KEY (id);


--
-- Name: respostas respostas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.respostas
    ADD CONSTRAINT respostas_pkey PRIMARY KEY (id);


--
-- Name: sessoes sessoes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessoes
    ADD CONSTRAINT sessoes_pkey PRIMARY KEY (id);


--
-- Name: simulado_respostas simulado_respostas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.simulado_respostas
    ADD CONSTRAINT simulado_respostas_pkey PRIMARY KEY (id);


--
-- Name: simulado_solicitacoes simulado_solicitacoes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.simulado_solicitacoes
    ADD CONSTRAINT simulado_solicitacoes_pkey PRIMARY KEY (id);


--
-- Name: simulado_tentativas simulado_tentativas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.simulado_tentativas
    ADD CONSTRAINT simulado_tentativas_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: idx_badges_aluno; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_badges_aluno ON public.badges_conquistados USING btree (aluno_id);


--
-- Name: idx_pontuacao_total; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pontuacao_total ON public.pontuacao USING btree (pontos_total DESC);


--
-- Name: idx_questoes_disciplina; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_questoes_disciplina ON public.questoes_banco USING btree (disciplina);


--
-- Name: idx_questoes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_questoes_status ON public.questoes_banco USING btree (status);


--
-- Name: idx_respostas_aluno; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_respostas_aluno ON public.respostas USING btree (aluno_id);


--
-- Name: idx_respostas_disciplina; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_respostas_disciplina ON public.respostas USING btree (disciplina);


--
-- Name: idx_respostas_questao; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_respostas_questao ON public.respostas USING btree (questao_id);


--
-- Name: idx_sessoes_aluno; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessoes_aluno ON public.sessoes USING btree (aluno_id);


--
-- Name: idx_sessoes_pagina; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessoes_pagina ON public.sessoes USING btree (pagina);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_key; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_key ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter);


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: users trg_new_user; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER trg_new_user AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


--
-- Name: perfis trg_perfis_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_perfis_updated_at BEFORE UPDATE ON public.perfis FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();


--
-- Name: pontuacao trg_pontuacao_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_pontuacao_updated_at BEFORE UPDATE ON public.pontuacao FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();


--
-- Name: progresso_revisao trg_progresso_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_progresso_updated_at BEFORE UPDATE ON public.progresso_revisao FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();


--
-- Name: questoes_banco trg_questoes_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_questoes_updated_at BEFORE UPDATE ON public.questoes_banco FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: badges_conquistados badges_conquistados_aluno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.badges_conquistados
    ADD CONSTRAINT badges_conquistados_aluno_id_fkey FOREIGN KEY (aluno_id) REFERENCES public.perfis(id) ON DELETE CASCADE;


--
-- Name: notificacoes_professor notificacoes_professor_professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notificacoes_professor
    ADD CONSTRAINT notificacoes_professor_professor_id_fkey FOREIGN KEY (professor_id) REFERENCES public.perfis(id) ON DELETE CASCADE;


--
-- Name: perfis perfis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perfis
    ADD CONSTRAINT perfis_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: pontuacao pontuacao_aluno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pontuacao
    ADD CONSTRAINT pontuacao_aluno_id_fkey FOREIGN KEY (aluno_id) REFERENCES public.perfis(id) ON DELETE CASCADE;


--
-- Name: progresso_revisao progresso_revisao_aluno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.progresso_revisao
    ADD CONSTRAINT progresso_revisao_aluno_id_fkey FOREIGN KEY (aluno_id) REFERENCES public.perfis(id) ON DELETE CASCADE;


--
-- Name: questoes_banco questoes_banco_gerada_para_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questoes_banco
    ADD CONSTRAINT questoes_banco_gerada_para_fkey FOREIGN KEY (gerada_para) REFERENCES public.perfis(id) ON DELETE SET NULL;


--
-- Name: questoes_banco questoes_banco_revisada_por_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.questoes_banco
    ADD CONSTRAINT questoes_banco_revisada_por_fkey FOREIGN KEY (revisada_por) REFERENCES public.perfis(id) ON DELETE SET NULL;


--
-- Name: respostas respostas_aluno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.respostas
    ADD CONSTRAINT respostas_aluno_id_fkey FOREIGN KEY (aluno_id) REFERENCES public.perfis(id) ON DELETE CASCADE;


--
-- Name: sessoes sessoes_aluno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessoes
    ADD CONSTRAINT sessoes_aluno_id_fkey FOREIGN KEY (aluno_id) REFERENCES public.perfis(id) ON DELETE CASCADE;


--
-- Name: simulado_respostas simulado_respostas_aluno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.simulado_respostas
    ADD CONSTRAINT simulado_respostas_aluno_id_fkey FOREIGN KEY (aluno_id) REFERENCES public.perfis(id) ON DELETE CASCADE;


--
-- Name: simulado_solicitacoes simulado_solicitacoes_professor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.simulado_solicitacoes
    ADD CONSTRAINT simulado_solicitacoes_professor_id_fkey FOREIGN KEY (professor_id) REFERENCES public.perfis(id) ON DELETE CASCADE;


--
-- Name: simulado_tentativas simulado_tentativas_aluno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.simulado_tentativas
    ADD CONSTRAINT simulado_tentativas_aluno_id_fkey FOREIGN KEY (aluno_id) REFERENCES public.perfis(id) ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: perfis aluno_atualiza_proprio_perfil; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY aluno_atualiza_proprio_perfil ON public.perfis FOR UPDATE USING ((id = auth.uid()));


--
-- Name: questoes_banco aluno_insert_questao_gerada; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY aluno_insert_questao_gerada ON public.questoes_banco FOR INSERT WITH CHECK (((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'aluno'::text) AND (p.ativo = true)))) AND (status = 'pendente'::text) AND (origem = 'ia_gerada'::text) AND (gerada_para = auth.uid())));


--
-- Name: questoes_banco aluno_select_questoes_aprovadas; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY aluno_select_questoes_aprovadas ON public.questoes_banco FOR SELECT USING (((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'aluno'::text) AND (p.ativo = true)))) AND ((status = ANY (ARRAY['aprovada'::text, 'editada'::text])) OR ((status = 'pendente'::text) AND (origem = 'ia_gerada'::text) AND (gerada_para = auth.uid())))));


--
-- Name: perfis professor_atualiza_perfil; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_atualiza_perfil ON public.perfis FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.perfis p2
  WHERE ((p2.id = auth.uid()) AND (p2.role = 'professor'::text)))));


--
-- Name: perfis professor_atualiza_qualquer_perfil; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_atualiza_qualquer_perfil ON public.perfis FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.perfis p2
  WHERE ((p2.id = auth.uid()) AND (p2.role = 'professor'::text)))));


--
-- Name: questoes_banco professor_delete_questao; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_delete_questao ON public.questoes_banco FOR DELETE USING ((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'professor'::text) AND (p.ativo = true)))));


--
-- Name: perfis professor_insere_perfil; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_insere_perfil ON public.perfis FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.perfis p2
  WHERE ((p2.id = auth.uid()) AND (p2.role = 'professor'::text)))));


--
-- Name: questoes_banco professor_insert_questao_manual; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_insert_questao_manual ON public.questoes_banco FOR INSERT WITH CHECK (((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'professor'::text) AND (p.ativo = true)))) AND (origem = 'manual'::text)));


--
-- Name: simulado_solicitacoes professor_insert_solicitacao_simulado; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_insert_solicitacao_simulado ON public.simulado_solicitacoes FOR INSERT WITH CHECK (((professor_id = auth.uid()) AND (EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'professor'::text) AND (p.ativo = true))))));


--
-- Name: pontuacao professor_le_todas_pontuacoes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_le_todas_pontuacoes ON public.pontuacao FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'professor'::text)))));


--
-- Name: progresso_revisao professor_le_todo_progresso; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_le_todo_progresso ON public.progresso_revisao FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'professor'::text)))));


--
-- Name: perfis professor_le_todos_perfis; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_le_todos_perfis ON public.perfis FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.perfis p2
  WHERE ((p2.id = auth.uid()) AND (p2.role = 'professor'::text)))));


--
-- Name: simulado_solicitacoes professor_select_solicitacoes_simulado; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_select_solicitacoes_simulado ON public.simulado_solicitacoes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'professor'::text) AND (p.ativo = true)))));


--
-- Name: questoes_banco professor_select_todas_questoes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_select_todas_questoes ON public.questoes_banco FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'professor'::text) AND (p.ativo = true)))));


--
-- Name: questoes_banco professor_update_questao; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_update_questao ON public.questoes_banco FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'professor'::text) AND (p.ativo = true)))));


--
-- Name: simulado_solicitacoes professor_update_solicitacao_simulado; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY professor_update_solicitacao_simulado ON public.simulado_solicitacoes FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.perfis p
  WHERE ((p.id = auth.uid()) AND (p.role = 'professor'::text) AND (p.ativo = true)))));


--
-- Name: simulado_solicitacoes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.simulado_solicitacoes ENABLE ROW LEVEL SECURITY;

--
-- Name: pontuacao usuario_atualiza_propria_pontuacao; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY usuario_atualiza_propria_pontuacao ON public.pontuacao FOR UPDATE USING ((aluno_id = auth.uid()));


--
-- Name: perfis usuario_atualiza_proprio_perfil; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY usuario_atualiza_proprio_perfil ON public.perfis FOR UPDATE USING ((id = auth.uid())) WITH CHECK ((id = auth.uid()));


--
-- Name: progresso_revisao usuario_atualiza_proprio_progresso; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY usuario_atualiza_proprio_progresso ON public.progresso_revisao FOR UPDATE USING ((aluno_id = auth.uid()));


--
-- Name: pontuacao usuario_le_propria_pontuacao; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY usuario_le_propria_pontuacao ON public.pontuacao FOR SELECT USING ((aluno_id = auth.uid()));


--
-- Name: perfis usuario_le_proprio_perfil; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY usuario_le_proprio_perfil ON public.perfis FOR SELECT USING ((id = auth.uid()));


--
-- Name: progresso_revisao usuario_le_proprio_progresso; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY usuario_le_proprio_progresso ON public.progresso_revisao FOR SELECT USING ((aluno_id = auth.uid()));


--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict HDDBCc7pLPnfDOEZtQxweTwgUyeFHLhcin0OSPratR2XZOO01ntjwRG62ophs7q

